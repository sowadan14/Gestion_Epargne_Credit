<table>
                    <tr>
                        <td>
                            <strong>Date commande:</strong> <?php echo e(\Carbon\Carbon::parse($cmde->DateAchat)->format('d/m/Y')); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Montant TTC:</strong> <?php echo e(number_format($cmde->MontantTTC,0,',',' ')); ?> <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Client:</strong> <?php echo e($cmde->client->Nom); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Status livraison:</strong> 
                            <?php

if(($cmde->MontantLivre/$cmde->MontantTTC)*100 < 99.9999 && ($cmde->MontantLivre/$cmde->MontantTTC)*100 > 99.9)
    {
    $StatusReception=99;
    }
    else
    {
    $StatusReception=round(($cmde->MontantLivre/$cmde->MontantTTC)*100);
    }
    ?>


                          
                            <div class="progress pos-rel" data-percent="<?php echo e($StatusReception); ?>%">
                                <div class="progress-bar" style="width:<?php echo e($StatusReception); ?>%;"></div>
                            </div>
                        </td>
                    </tr>
                </table><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/vente/livrs/detailCmde.blade.php ENDPATH**/ ?>