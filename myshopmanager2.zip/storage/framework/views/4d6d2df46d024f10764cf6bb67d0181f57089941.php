
<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type=file]::file-selector-button {
        margin-right: 5px;
        border: none;
        background: #084cdf;
        padding: 10px 5px;
        border-radius: 10px;
        color: #fff;
        cursor: pointer;
        transition: background .2s ease-in-out;
    }

    input[type=file]::file-selector-button:hover {
        background: #0d45a5;
    }



    .drop-container {
        position: relative;
        display: flex;
        margin: 10px;
        gap: 10px;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: inherit;
        padding: 5px;
        border-radius: 10px;
        border: 2px dashed #555;
        color: #444;
        cursor: pointer;
        transition: background .2s ease-in-out, border .2s ease-in-out;
    }

    .drop-container:hover {
        background: #eee;
        border-color: #111;
    }

    .drop-container:hover .drop-title {
        color: #222;
    }

    .drop-title {
        color: #444;
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        transition: color .2s ease-in-out;
    }

    td,
    th {
        padding: 5px;
    }

    .innerTd {
        width: 100px;
    }

    .active {
        background-color: aqua;
    }

    #navMenus {
        list-style: none;
    }

    li {
        cursor: pointer;
        margin-bottom: 5px;
    }

    ul {
        margin-left: 0px;
    }

    .tableRecap td {
        white-space: nowrap;
        border-top: 0px solid #ddd;
    }

    .tableRecap td:first-child {
        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    .tableRecap td:last-child {
        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    .tableRecap>tbody>tr>td,
    .tableRecap>tbody>tr>th,
    .tableRecap>tfoot>tr>td,
    .tabtableRecaple>tfoot>tr>th,
    .tableRecap>thead>tr>td,
    .tableRecap>thead>tr>th {
        padding: 2px;
        line-height: 1.42857143;
        vertical-align: middle;
        border-top: 1px solid #ddd0;
    }
</style>

<?php echo Form::model($cmde, ['method' => 'PATCH','route' => ['registers.update', $cmde->id]]); ?>


<div class="EnteteContent">
    <div class="row">

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
            <i class=" icon-cart31 bigger-130"></i> Gestion régistres achats
        </div>

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
            modification d'un achat
        </div>
    </div>
    <hr class="hrEntete">
    <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

    <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
    <div class="row">
    <input type="text" name="id" id="id" value="<?php echo e($cmde->id); ?>" hidden>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:0 25px 0 25px;">
                <div class="form-group row">

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Fournisseur</strong>
                        <div>
                            <select name="FournisseurId" id="FournisseurId">
                                <option value="">Séléctionner un fournisseur</option>
                                <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fournisseur->id); ?>" <?php echo e((old('FournisseurId',$cmde->FournisseurId)==$fournisseur->id) ? 'selected' : ''); ?>>
                                    <?php echo e($fournisseur->Nom); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('FournisseurId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('FournisseurId')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Mode paiement</strong>
                        <div>
                            <select name="ModePaiementId" id="ModePaiementId">
                                <option value="">Séléctionner un mode paiement</option>
                                <?php $__currentLoopData = $modepaiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modepaiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($modepaiement->id); ?>" <?php echo e((old('ModePaiementId',$cmde->ModePaiementId)==$modepaiement->id) ? 'selected' : ''); ?>>
                                    <?php echo e($modepaiement->Nom); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('ModePaiementId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('ModePaiementId')); ?></span>
                        <?php endif; ?>
                    </div>


                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Compte</strong>
                        <div>
                            <select name="CompteId" id="CompteId">
                                <option value="">Séléctionner un compte</option>
                                <?php $__currentLoopData = $comptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($compte->id); ?>" <?php echo e((old('CompteId',$cmde->CompteId)==$compte->id) ? 'selected' : ''); ?>>
                                    <?php echo e($compte->Libelle); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('CompteId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CompteId')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Référence</strong>
                        <input class="form-control" name="Reference" value="<?php echo e(old('Reference',$cmde->Reference)); ?>" type="text">

                        <?php if($errors->has('Reference')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Reference')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Date commande</strong>
                        <input class="form-control datepicker text-center" name="DateAchat" value="<?php echo e(old('DateAchat',\Carbon\Carbon::parse($cmde->DateAchat)->format('d/m/Y'))); ?>" type="text">
                        <?php if($errors->has('DateAchat')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateAchat')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Date réception</strong>
                        <input class="form-control datepicker text-center" name="DateReception" value="<?php echo e(old('DateReception',\Carbon\Carbon::parse($cmde->DateReception)->format('d/m/Y'))); ?>" type="text">
                        <?php if($errors->has('DateReception')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateReception')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

<div class="EnteteContent">
    <div class="form-group row">
        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 table-responsive" style="overflow-y: scroll;max-height:250px;font-weight:bold;font-size:80%;">
            Produits:
            <!-- <input type="text" id="myInput" class="form-control FilterSearch"> -->

            <ul id="navMenus">
                <li>
                    <div><input class="FilterSearch form-control" type="text" /></div>
                </li>
                <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li id="<?php echo e($produit->id); ?>" class="SelectProduit selector"><?php echo e($produit->Libelle); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="padding:5px;">
                    <div>
                        <select name="UniteId" id="UniteId">
                            <option value="">Séléctionner une unité</option>
                            <!-- <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unite->id); ?>" <?php echo e((old('UniteId')==$unite->id) ? 'selected' : ''); ?>>
                                <?php echo e($unite->Nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                        </select>
                    </div>
                    <?php if($errors->has('UniteId')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('UniteId')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" style="margin-top:5px;">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 bolder">Remise globale:</div>
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"><input class="form-control text-right remiseglobale" name="Remiseglobale" value="<?php echo e(old('Remiseglobale',$cmde->RemiseGlobale)); ?>" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;"></div>
                    <!-- </tr>
                        <tr> -->
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 bolder">Montant à payer :</div>
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"><input class="form-control text-right MontantPaye" name="MontantPaye" value="0" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;"></div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="overflow-y: scroll;max-height:180px;">
                    <table class="table table-bordered " id="TableOfData" style="font-size:80%;">
                        <tr style="background:#006fcf;color:#FFF;font-weight:bold;">

                            <td hidden>Unité</td>
                            <td>Produit</td>
                            <td>Unité</td>
                            <td class="text-right innerTd">Qté cmdée</td>
                            <td class="text-right innerTd">Qté reçue</td>
                            <td class="text-right innerTd">Prix Achat</td>
                            <td class="text-right innerTd">Remise (%)</td>
                            <td class="text-right innerTd">TVA (%)</td>
                            <td class="text-right">Montant TTC</td>
                            <td class="text-center">Action</td>
                        </tr>
                        <tbody id="DetailsUnites">
                            <?php if($cmde->produits->count()>0): ?>
                            <?php $__currentLoopData = $cmde->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmde_produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>'>
                                <td><?php echo e($cmde_produit->Libelle); ?></td>
                                <td><?php echo e($cmde_produit->unites->where('id',$cmde_produit->pivot->UniteId)->first()->Nom); ?></td>
                                <td hidden><input class='text-right form-control' name='Produit[]' value='<?php echo e($cmde_produit->id); ?>' type='number'></td>
                                <td hidden><input class='text-right form-control' name='Unite[]' value='<?php echo e($cmde_produit->pivot->UniteId); ?>' type='number'></td>
                                <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='Qte[]' min='0' value="<?php echo e(old('Qte',$cmde_produit->pivot->Qte)); ?>" type='number' required /></td>
                                <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='QteRecus[]' min='0' value="<?php echo e(old('QteRecus',$cmde_produit->pivot->QteReçu)); ?>" type='number' required /></td>
                                <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='PrixAchat[]' min='0' value='<?php echo e($cmde_produit->pivot->Prix); ?>' type='number' required /></td>
                                <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='Remise[]' min='0' value='<?php echo e($cmde_produit->pivot->Remise); ?>' type='number' required /></td>
                                <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='TVA[]' min='0' value='<?php echo e($cmde_produit->pivot->Tva); ?>' type='number' required /></td>
                                <td class='text-right'><?php echo e(number_format($cmde_produit->pivot->Montant,0,',',' ')); ?></td>
                                <td hidden><input class='text-right form-control' name='MontantTTC[]' value='<?php echo e($cmde_produit->pivot->Montant); ?>' type='number'></td>
                                <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this' style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>'><span class='fa fa-trash'></span></button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-right">
                        <table class="table tableRecap" style="font-size:80%;text-align:right;border-top:0px solid ;margin-bottom:0px;">
                            <tr>
                                <td class="bolder">TOTAL HT :</td>
                                <td class=""><span class="mtht">0</span></td>

                                <td class="bolder">TOTAL REMISE :</td>
                                <td class=""><span class="mtremise">0</span></td>


                                <td class="bolder">TOTAL TVA : </td>
                                <td class=""><span class="mttva">0</span></td>

                                <td class="bolder">TOTAL TTC : </td>
                                <td class=""><span class="mtttc">0</span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="form-group" style="float:right;margin:15px;">
    <a href="<?php echo e(url('/recouv/registers')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des achats</span></a>

    <button type="submit" value="Create" class="btn btn-warning btn-sm bolder">
        <i class="glyphicon glyphicon-edit"></i> Modifier
    </button>
</div>
<?php echo Form::close(); ?>



<script type="text/javascript">
    $(document).ready(function() {

        localStorage.setItem("myclass", 'registerachat');
        localStorage.setItem("father", 'achat');

        CalculeSumChamps("TableOfData");

        $(document).on("input propertychange paste change", '.FilterSearch', function(e) {
            var value = $(this).val().toLowerCase();
            $(this).parents("ul").find('li:not(li:first-of-type)').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });

        });

        function toNumberFormat(value) {
            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        }

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })

        $(document).on('click', '.remove_this', function() {
            var DivName = $(this).attr("name");
            $("." + DivName).remove();
            CalculeSumChamps("TableOfData");
            return false;
        });



        $('#ModePaiementId').chosen();
        $("#ModePaiementId_chosen").css("width", "100%");

        $('#FournisseurId').chosen();
        $("#FournisseurId_chosen").css("width", "100%");

        $('#UniteId').chosen();
        $("#UniteId_chosen").css("width", "100%");

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $("#navMenus").on('click', 'li.selector', function() {
            var produitId = $(this).attr('id');
            $("#navMenus li.active").removeClass("active");
            // adding classname 'active' to current click li 
            $(this).addClass("active");
            if (produitId != "") {
                $('#UniteId').empty();
                $("#UniteId").append("<option value=''>Séléctionnez une unité</option>");
                $.ajax({
                    url: "<?php echo e(url('achat/cmdes/getUnites')); ?>",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        id: produitId
                    },
                    success: function(data) {
                        $.each(data.split('|'), function(index, value) {
                            if (value != "") {
                                $("#UniteId").append("<option value='" + value.split(
                                        '~')[0] + "' " + value.split('~')[2] + ">" +
                                    value.split('~')[1] + "</option>");
                            }
                        });
                        $('#UniteId').trigger("chosen:updated");
                        let UniteId = $('#UniteId').val();
                        setLineProduit(produitId, UniteId);
                    }
                });
            }


        });


        function setLineProduit(ProduitId, UniteId) {
            if (ProduitId != "" && UniteId != "") {
                if ($('.PUnite' + UniteId.split('/')[0] + "" + ProduitId).length < 1) {
                    $("#DetailsUnites").append("<tr  class='PUnite" + UniteId.split('/')[0] + "" + ProduitId + "'>\
                      <td>" + $("#navMenus li.active").html() + "</td>\
                      <td>" + $('#UniteId option:selected').text() + "</td>\
                      <td hidden><input class='text-right form-control' name='Produit[]' value='" + ProduitId + "'  type='number'></td>\
                      <td hidden><input class='text-right form-control' name='Unite[]' value='" + UniteId.split('/')[
                            0] + "'  type='number'></td>\
                      <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='Qte[]' min='0' value='0' type='number' required /></td>\
                        <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='QteRecus[]' min='0' value='0' type='number' required /></td>\
                     <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='PrixAchat[]' value='" + UniteId.split('/')[1] + "'  min='0' type='number' required /></td>\
                      <td><input class='text-right form-control' list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='Remise[]'  value='0'  min='0' type='number' required /></td>\
                      <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='TVA[]'  value='<?php echo e(auth()->user()->entreprise->TVA); ?>'  min='0' type='number' required /></td>\
                      <td  class='text-right'>0</td>\
                      <td hidden><input class='text-right form-control' name='MontantTTC[]'  type='number'></td>\
                      <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this'\
                      style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite" + UniteId.split(
                            '/')[0] + "" + ProduitId + "'><span class='fa fa-trash'></span></button></td>\
                      </tr>");
                }
            }

        }

        function CalculeSumChamps(tableID) {
            var montantht = 0;
            var montantremise = 0;
            var montanttva = 0;
            var montantttc = 0;

            var montanthtRecu = 0;
            var montantremiseRecu = 0;
            var montanttvaRecu = 0;
            var montantttcRecu = 0;


            var qte = 0;
            $("#" + tableID + " tbody#DetailsUnites tr").each(function() {
                var Qte = parseFloat(($(this).find("td").eq(4).find("input").val()).replace(/ /g, ''));
                var Qterecu = parseFloat(($(this).find("td").eq(5).find("input").val()).replace(/ /g, ''));
                var Prix = parseFloat(($(this).find("td").eq(6).find("input").val()).replace(/ /g, ''));
                var remise = parseFloat(($(this).find("td").eq(7).find("input").val()).replace(/ /g, ''));
                var tva = parseFloat(($(this).find("td").eq(8).find("input").val()).replace(/ /g, ''));


                var mtht = parseFloat(Qte * Prix);
                var mtremise = Math.round(parseFloat((mtht * remise) / 100));
                var mttva = Math.round(parseFloat(((mtht * tva) / 100)));

                var mthtRecu = parseFloat(Qterecu * Prix);
                var mtremiseRecu = Math.round(parseFloat((mtht * remise) / 100));
                var mttvaRecu = Math.round(parseFloat(((mtht * tva) / 100)));


                montantht += mtht;
                montantremise += mtremise;
                montanttva += mttva;
                montantttc += parseFloat(parseFloat(mtht) + parseFloat(mttva) - parseFloat(mtremise));

                montanthtRecu += mthtRecu;
                montantremiseRecu += mtremiseRecu;
                montanttvaRecu += mttvaRecu;
                montantttcRecu += parseFloat(parseFloat(mthtRecu) + parseFloat(mttvaRecu) - parseFloat(mtremiseRecu));
            });


            var remiseglobale = $(".remiseglobale").val();
            $(".mtht").html(toNumberFormat(montantht));
            $(".mtremise").html(toNumberFormat(montantremise + parseFloat(remiseglobale)));
            $(".mttva").html(toNumberFormat(montanttva));
            $(".mtttc").html(toNumberFormat(montantttc - parseFloat(remiseglobale)));
            $(".MontantPaye").val(montantttcRecu - parseFloat(remiseglobale));

        }

        function CalculeSumPayerChamps(tableID) {
            var montantht = 0;
            var montantremise = 0;
            var montanttva = 0;
            var montantttc = 0;
            var qte = 0;
            $("#" + tableID + " tbody#DetailsUnites tr").each(function() {
                var Qte = parseFloat(($(this).find("td").eq(5).find("input").val()).replace(/ /g, ''));
                var Prix = parseFloat(($(this).find("td").eq(6).find("input").val()).replace(/ /g, ''));
                var remise = parseFloat(($(this).find("td").eq(7).find("input").val()).replace(/ /g, ''));
                var tva = parseFloat(($(this).find("td").eq(8).find("input").val()).replace(/ /g, ''));


                var mtht = parseFloat(Qte * Prix);
                var mtremise = Math.round(parseFloat((mtht * remise) / 100));
                var mttva = Math.round(parseFloat(((mtht * tva) / 100)));

                montantht += mtht;
                montantremise += mtremise;
                montanttva += mttva;
                montantttc += parseFloat(parseFloat(mtht) + parseFloat(mttva) - parseFloat(mtremise));
            });
            var remiseglobale = $(".remiseglobale").val();
            $(".MontantPaye").val(montantttc - parseFloat(remiseglobale));

        }


        $('#UniteId').on('change', function(e) {
            let ProduitId = $("#navMenus li.active").attr('id');
            let UniteId = $('#UniteId').val();
            setLineProduit(ProduitId, UniteId);
        });



        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Remiseglobale"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            CalculeSumChamps("TableOfData");
        });


        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Qte[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));

            $("#TableOfData tbody#DetailsUnites tr." + $(this).attr('list')).find("td").eq(5).find("input").val(Qte);
            CalculeSumChamps("TableOfData");
        });

        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Remise[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));

            CalculeSumChamps("TableOfData");
        });


        $(document).on("change", 'input[name="QteRecus[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            CalculeSumPayerChamps("TableOfData");
        });

        $(document).on("change", 'input[name="PrixAchat[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));
            CalculeSumChamps("TableOfData");
        });

        $(document).on("change", 'input[name="TVA[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));
            CalculeSumChamps("TableOfData");
        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/achat/registers/edit.blade.php ENDPATH**/ ?>