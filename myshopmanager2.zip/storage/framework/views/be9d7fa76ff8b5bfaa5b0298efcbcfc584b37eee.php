<style type="text/css">
    .label-lg {
    padding: 0.2em 0.6em 0.4em;
    font-size: 13px;
    line-height: 1.1;
    height: 24px;
}
</style>
<div style="overflow-y:auto;max-height:450px;margin:15px;">
<div class="form-group row">
 
 <div class="col-xs-12 col-sm-12 col-md-11 col-lg-11" style="padding-left:25px;font-weight:bold;font-size:15px;">
         <strong>Libellé:</strong>
         <?php echo e($role->name); ?>

 </div>
 <br>
 <div class="col-xs-12 col-sm-12 col-md-12">
     <div class="">
       <br>
         <div class="form-group row" style="padding-left:15px;">
           <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
               <p style="font-weight:bold;font-size:15px;margin-bottom: 0.1rem">Permissions:</p>
           </div>
       </div>
         <div>
         <?php if(!empty($rolePermissions)): ?>
           <?php $__currentLoopData = $numParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numParent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-lg-4 col-md-4 col-sm-12">
           <div class="col-xs-11 label label-lg label-info  arrowed-right" style="padding: 0.em 0.6em 0.4em;">
           <label style="text-align:left"><?php echo e($rolePermissions->where('NumParent',$numParent)->first()->Parent); ?></label>
           </div>
           <div style="margin-bottom:10px;margin-top:28px;">
             <?php $__currentLoopData = $rolePermissions->where('NumParent',$numParent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
           <label><i class="glyphicon glyphicon-ok"></i>
               <?php echo e($value->Libelle); ?> <?php echo $value->Lien; ?> </label>
           <br/>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
           </div>
        
     </div>
 </div>
 
</div>
</div>
<?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/roles/show.blade.php ENDPATH**/ ?>