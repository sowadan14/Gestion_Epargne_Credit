
<?php $__env->startSection('content'); ?>
<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
<?php echo Form::model($typeproduit, ['method' => 'PATCH','route' => ['tprods.update', $typeproduit->id]]); ?>


    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                <i class="icon-ticket   bigger-130"></i> Gestion des types produit
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Modification d'un type produit
            </div>
        </div>
        <hr  class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row">
            <input type="text" name="id" id="id" value="<?php echo e($typeproduit->id); ?>" hidden>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:0 25px 0 25px;">
                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code</strong>
                        <input class="form-control" name="Code"  value="<?php echo e(old('Code',$typeproduit->Code)); ?>"  type="text">
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Libellé</strong>
                        <input class="form-control" name="Nom"  value="<?php echo e(old('Nom',$typeproduit->Nom)); ?>"  type="text" required>
                        <?php if($errors->has('Nom')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Nom')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong></strong>
                        <label style="margin-top:25px;"><input name="Status" value="on"    <?php if((!old() && $typeproduit->Status) || old('Status') == 'on'): ?> checked="checked" <?php endif; ?> type="checkbox">
                            Actif</label>
                    </div>
                </div>

               
            </div>
        </div>
    </div>
    <div class="form-group " style="float:right;">
                    <a href="<?php echo e(url('/config/tprods')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des types produit</span></a>

                    <button type="submit" value="Create" class="btn btn-warning btn-sm bolder">
                        <i class="glyphicon glyphicon-edit"></i> Modifier
                    </button>
                </div>
    <?php echo Form::close(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/tprods/edit.blade.php ENDPATH**/ ?>