 <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
          <span class="sr-only">Toggle sidebar</span>

          <span class="icon-bar"></span>

          <span class="icon-bar"></span>

          <span class="icon-bar"></span>
        </button>

        <div class="navbar-header pull-left">
          <a href="index.html" class="navbar-brand">
            <small style="font-family:'ga_isar_catregular';font-size:25px;font-style:italic;margin-left: -20px;margin-right: 0px;display:inline-block">
              <i class="fa fa-shopping-cart"></i>
              MSN:NORA
            </small>
          </a>
        </div>

        <div class="navbar-buttons navbar-header pull-right" role="navigation">
        <ul class="nav ace-nav">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <!-- <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?> -->
                        <?php else: ?>
                            <li class="light-blue">
                                <!-- <a href="#">
                <img class="nav-user-photo" src="<?php echo e(url('assets/images/avatars/user.jpg')); ?>" alt="Jason's Photo" />
                <span class="user-info">
                  <small>Welcome,</small>
                  <?php echo e(Auth::user()->email); ?>

                </span>
              </a> -->
              <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-link dropdown-user-link"><span><img src ="<?php echo e(url('assets/images/avatars/user.jpg')); ?>" style="width:30px;height:30px;border-radius:100px;" alt="avatar" /><i></i></span><span class="user-name" style="font-family:'ga_isar_catregular'"> SEMEGLO Ablam</span></a>
              </li>
            <li class="light-blue">
            <a class="log-out-btn" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();"> 
            <img class="nav-user-photo" src="<?php echo e(url('assets/images/Files/LogOff.png')); ?>" />
            </a>

 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

  </form>
            <!-- <a class="nav-link" href="login"><?php echo e(__('Logout')); ?></a> -->
              <!-- <a href="/login"> -->
                <!-- <img class="nav-user-photo" src="<?php echo e(url('assets/images/Files/LogOff.png')); ?>" /> -->
                <!-- <a class="dropdown-item" href="<?php echo e(route('login')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a> -->
              <!-- </a> -->
            </li>

                                <!-- <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div> -->
                            </li>
                        <?php endif; ?>
                    </ul>
          <!-- <ul class="nav ace-nav">
            <li class="light-blue">
              <a href="#">
                <img class="nav-user-photo" src="<?php echo e(url('assets/images/avatars/user.jpg')); ?>" alt="Jason's Photo" />
                <span class="user-info">
                  <small>Welcome,</small>
                  JasonsemegloablamJohsoncoucoucoucoucuc
                </span>
              </a>
            </li>
            <li class="light-blue">
              <a href="/login">
                <img class="nav-user-photo" src="<?php echo e(url('assets/images/Files/LogOff.png')); ?>" />
              </a>
            </li>
          </ul> -->
        </div><?php /**PATH C:\xampp\htdocs\MyShopManager30012023\MyShopManager\resources\views/layouts/header.blade.php ENDPATH**/ ?>