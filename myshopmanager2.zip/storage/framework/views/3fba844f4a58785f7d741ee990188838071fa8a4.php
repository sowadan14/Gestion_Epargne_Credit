
<?php $__env->startSection('content'); ?>

<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                <i class="menu-icon icon-cogs2 bigger-130"></i> Configuration
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Aperçu général
            </div>
        </div>
        <hr class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 showStyle">
                <div class="form-group row col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-xs-11 label label-lg label-info  arrowed-right"
                            style="padding: 0.em 0.6em 0.4em;">
                            <label style="text-align:left">Infos de la société</label>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Code:</strong> <?php echo e($data->Code); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Nom:</strong> <?php echo e($data->Nom); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Nom réduit:</strong> <?php echo e($data->NomReduit); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Téléphone:</strong> <?php echo e($data->Telephone); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Adresse éléctronique:</strong> <?php echo e($data->Email); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Adresse:</strong> <?php echo e($data->Adresse); ?>

                        </div>
                    </div>


                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-xs-11 label label-lg label-info  arrowed-right"
                            style="padding: 0.em 0.6em 0.4em;">
                            <label style="text-align:left">Mise en forme de la société</label>
                        </div>
                        <div style="margin-bottom:10px;margin-top:28px;">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Taille: </strong> <?php echo e($data->Taille); ?>px
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Police: </strong> <?php echo e($data->Police); ?>

                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Couleur entête: </strong>  <span
                                    style="background-color:<?php echo e($data->ColorEntete); ?>;width:100px;height:15px;color:<?php echo e($data->ColorEntete); ?>;border:1px solid #100f0f;">Header </span>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <strong>Couleur menu: </strong> <span style="background-color:<?php echo e($data->ColorSidebar); ?>;width:100px;height:15px;color:<?php echo e($data->ColorSidebar); ?>;border:1px solid #100f0f;">Header </span>
                        </div>

                        </div>
                    </div>

                  

                </div>

                <div class="form-group row col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-xs-11 label label-lg label-info  arrowed-right"
                            style="padding: 0.em 0.6em 0.4em;">
                            <label style="text-align:left">Logo de la société</label>
                        </div>
                        <div style="margin-bottom:10px;margin-top:28px; text-align:center;">
                        <img id="blah" src="<?php echo e(asset('storage/images/'.$data->LogoEntreprise)); ?>" alt="User photo"
                                width="300px" height="300px" style="border-radius:200px;" />

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/index.blade.php ENDPATH**/ ?>