
<?php $__env->startSection('content'); ?>
<style tyle="css/text">
.label {
    font-weight: 900;
    font-size: 12px;
    text-align:left;
}

label {
    font-weight: 900;
}

.label-lg {
    padding: 0.008em 0.6em 0.4em;
    font-size: 13px;
    line-height: 1.1;
    height: 24px;
}
</style>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createuser')): ?>
<p>
<a class="btn btn-md btn-round btn-primary" href="javascript:void(0)" id="adduser"><span class=" glyphicon glyphicon-plus"></span> Nouveau</a>
</p>

<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<?php if($message = Session::get('danger')): ?>
<div class="alert alert-danger">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>



<!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-stripped data-table">
            <thead>
              <tr>
                <th>N°</th>
                <th>Nom</th>
                <th>Email</th>
                <th class="text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(is_countable($data) && count($data) > 0): ?>

				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<!-- <td><img src="<?php echo e(asset('images/' . $row->student_image)); ?>" width="75" /></td> -->
						<td><?php echo e($row->id); ?></td>
						<td><?php echo e($row->employe->Nom); ?>  <?php echo e($row->employe->Prenoms); ?></td>
                        <td><?php echo e($row->email); ?></td>
						<!-- <td><?php echo e($row->student_gender); ?></td> -->
						<td class="text-center">
           
							<a href="javascript:void(0)" data-toggle="tooltip"  data-id="<?php echo e($row->id); ?>" data-original-title="Details" class="btn btn-default btn-sm showRole" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edituser')): ?>
              <a href="javascript:void(0)" data-toggle="tooltip"  data-id="<?php echo e($row->id); ?>" data-original-title="Modifier" class="btn btn-warning btn-sm editRole"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteuser')): ?>
              <a href="javascript:void(0)" data-toggle="tooltip"  user="<?php echo e($row->email); ?>"  data-id="<?php echo e($row->id); ?>" data-original-title="Supprimer" class="btn btn-danger btn-sm deleteRole"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>
              <?php endif; ?>
						</td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<?php else: ?>
				<tr>
					<td colspan="3" class="text-center">No Data Found</td>
				</tr>
			<?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="ajaxModel"  data-backdrop="false" data-keyboard="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
            <div class="alert alert-danger" style="display:none"></div>
            <div class="PartianDiv">
             
            </div>
               
              </div>
            <div class="modal-footer">
            <div class="col-sm-12">
            <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:left;"><i class="ace-icon fa fa-times"></i> Fermer</button>
           <button type="button" id="CreateForm" value="Create" class="btn btn-primary Saver btn-md btn-round" style="background-color:orange;" >
           <i class="ace-icon fa fa-floppy-o bigger-120"></i> Enregistrer
            </button>
                    </div>
                   
                    </div>
      </div>
  </div>
</div>

<div class="modal fade" id="deleteAjaxModel"  data-backdrop="false" data-keyboard="false">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="deleteModelHeading"></h4>
          </div>
          <form action="" id="deleteForm" name="deleteForm" method="POST" class="form-horizontal">

          <div class="modal-body">
              <?php echo e(method_field('DELETE')); ?>

              <?php echo e(csrf_field()); ?>

              <!-- <input type='hidden' name="_method"></input> -->
                 <div class="form-group">
                  <input type="hidden" name="deletePosteid" id="deletePosteid">
                  <div class="col-sm-12 forDelete" style="color:red;font-weight: bold;">
                   
                  </div>
                </div>
          </div>
          <div class="modal-footer">
            <div class="col-sm-12">
              <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:left;"><i class="ace-icon fa fa-times"></i> Fermer</button>
             <button type="submit" id="DeleteBtn" value="Delete" class="btn btn-danger Saver btn-md btn-round">
             <i class="ace-icon fa fa-trash-o bigger-120"></i> Supprimer
              </button>
                      </div>
                 
</div>
</form>

      </div>
  </div>
</div>

<script type="text/javascript">


$(document).ready(function () {

   
   
      $(document).on('change', 'input:checkbox', function () {
      var id=$(this).attr('user');
            $("input:checkbox."+id).prop('checked', $(this).prop("checked"));
        });
    /*------------------------------------------
     --------------------------------------------
     Pass Header Token
     --------------------------------------------
     --------------------------------------------*/ 
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
      
    /*------------------------------------------
    --------------------------------------------
    Render DataTable
    --------------------------------------------
    --------------------------------------------*/
    var table = $('.data-table').DataTable({
      "language": {
            "thousands": ' ',
            "decimal": ",",
            "thousands": " ",
            "sProcessing": "Traitement en cours...",
            "sSearch": "Rechercher&nbsp;:",
            "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
            "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
            "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
            "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
            "sInfoPostFix": "",
            "sLoadingRecords": "Chargement en cours...",
            "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
            "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
            "oPaginate": {
                "sFirst": "Premier",
                "sPrevious": "Pr&eacute;c&eacute;dent",
                "sNext": "Suivant",
                "sLast": "Dernier"
            },
            "oAria": {
                "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
            }
        },
        processing: true,
        // serverSide: true,
        "order": [[0, 'desc']],
        // ajax: "<?php echo e(route('users.index')); ?>",
        // columns: [
        //     // {data: 'DT_RowIndex', name: 'DT_RowIndex'},
        //     {data: 'id', name: 'id'},
        //     {data: 'Libelle', name: 'Libelle'},
        //     {data: 'action', name: 'action', orderable: false, searchable: false,class:'text-center'},
        // ]
    });
      
    /*------------------------------------------
    --------------------------------------------
    Click to Button
    --------------------------------------------
    --------------------------------------------*/
    // $('#adduser').click(function () {
    //   jQuery('.alert-danger').html('');

    //     $('#CreateForm').removeClass("btn-warning").addClass('btn-primary');
    //     $('#id').val('');
    //     $('#userForm').trigger("reset");
    //     $('#modelHeading').html("<i class='glyphicon glyphicon-plus'></i> Nouveau rôle");
    //     $('#ajaxModel').modal('show');
    // });

    $('#adduser').click(function (e) {
      jQuery('.alert-danger').hide();
        jQuery('.alert-danger').html('');
        $('#CreateForm').removeClass("btn-warning").addClass('btn-primary');
        $('#id').val('');
        $('#userForm').trigger("reset");
        $('#CreateForm').show();
        $('#modelHeading').html("<i class='glyphicon glyphicon-plus'></i> Nouveau rôle"); 
        $('.Closer').css('float','left');          
        e.preventDefault();
        $.ajax({
          data:{},
          url: "<?php echo e(route('users.create')); ?>",
          type: "GET",
          // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          dataType: 'json',
          success: function (data) {
              $('.PartianDiv').html(data.html);
              $('#ajaxModel').modal('show');
           
          },
          error: function (data) {
            
          }
      });
    });


    // $("#checkAllUser").change(function () {
      $(document).on('change', '#checkAllUser', function () {
            $("input:checkbox").prop('checked', $(this).prop("checked"));
        });
      
    /*------------------------------------------
    --------------------------------------------
    Click to Edit Button
    --------------------------------------------
    --------------------------------------------*/
   


    $(document).on('click', '.editRole', function (e) {
      jQuery('.alert-danger').hide();
      e.preventDefault();
      var user_id = $(this).data('id');
        jQuery('.alert-danger').html('');
        $('#CreateForm').addClass('btn-warning').removeClass("btn-primary");
        $('#userForm').trigger("reset");
        $('#CreateForm').show();
        $('#modelHeading').html("<i class='glyphicon glyphicon-edit'></i> Modification d'un rôle");
        $('.Closer').css('float','left');    
        $.ajax({
          data:{},
          url:"<?php echo e(route('users.index')); ?>" +'/' + user_id +'/edit',
          type: "GET",
          // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          dataType: 'json',
          success: function (data) {
              $('.PartianDiv').html(data.html);
              $('#ajaxModel').modal('show');
          },
          error: function (data) {
            
          }
      });
    });

   


    $(document).on('click', '.showRole', function (e) {
      jQuery('.alert-danger').hide();
      e.preventDefault();
      var user_id = $(this).data('id');
        jQuery('.alert-danger').html('');
        $('#CreateForm').hide();
        $('#modelHeading').html("<i class='ace-icon fa fa-eye'></i> Details d'un rôle");
        $('.Closer').css('float','right');      
          // $('#ajaxModel').modal('show');
       
        $.ajax({
          data:{},
          url:"<?php echo e(route('users.index')); ?>" +'/' + user_id,
          type: "GET",
          // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          dataType: 'json',
          success: function (data) {
              $('.PartianDiv').html(data.html);
              $('#ajaxModel').modal('show');
           
          },
          error: function (data) {
            
          }
      });
    });


   
   
      
    /*------------------------------------------
    --------------------------------------------
    Create Product Code
    --------------------------------------------
    --------------------------------------------*/
    $('#CreateForm').click(function (e) {
        e.preventDefault();
        AmagiLoader.show();
        $.ajax({
          data: $('#userForm').serialize(),
          url: "<?php echo e(route('users.store')); ?>",
          type: "POST",
          // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          dataType: 'json',
          success: function (data) {
              if(data.errors)
                  	{
                  		jQuery('.alert-danger').html('');
                      AmagiLoader.hide();
                  		jQuery.each(data.errors, function(key, value){
                  			jQuery('.alert-danger').show();
                  			jQuery('.alert-danger').append('<li>'+value+'</li>');
                  		});
                  	}
                  	else
                  	{
                      $('#ajaxModel').modal('hide');
                      $('#userForm').trigger("reset");
              window.location=data.url;
              AmagiLoader.hide();
             
                  	}
           
          },
          error: function (data) {
            
          }
      });
    });

    
    $(document).on('click', '.deleteRole', function () {
          var id = $(this).data('id');
          var Libelle = $(this).attr('user');
          $('#deleteModelHeading').html("<i class='ace-icon fa fa-trash-o bigger-120'></i> Suppression d'un rôle");
          $('#deleteAjaxModel').modal('show');
          $("#deleteuserid").val(id);
          $("#deleteForm").attr('action','/users/'+id);
          $('.forDelete').html("Voulez-vous vraiment supprimer le rôle: "+Libelle+"?");
    
    });
    
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/users/index.blade.php ENDPATH**/ ?>