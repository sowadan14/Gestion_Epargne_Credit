
<link  href="assets/css/chosen.min.css" rel="stylesheet" />
    <script src="assets/js/chosen.jquery.min.js"></script>

<form id="employeForm" name="employeForm" method="post" class="form-horizontal">
                <input type="hidden" name="id" id="id">
                <div style="overflow-y:auto;max-height:450px;margin:15px;">
            <div class="alert alert-danger" style="display:none"></div>


<div class="col-lg-12 col-md-12 col-sm-12">
           <div style="margin-bottom:10px;margin-top:28px;">
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
                <strong>Nom:</strong>
                <input class="form-control" name="Nom"  value="{{old('Nom')}}"  type="text">
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
            <strong>Prenoms:</strong>
            <input class="form-control" name="prenoms" type="text">
    </div>
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
        <strong>Sexe:</strong>
        <div>
        <select name="sexe"  id="sexe">
        <option value="">Séléctionner un sexe</option>
        <?php $__currentLoopData = $sexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($sexe->value); ?>"><?php echo e($sexe->text); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
        </div>
</div>
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
        <strong>Poste:</strong>
        <div>
        <select name="posteId"  id="posteId">
        <option value="">Séléctionner un poste</option>
        <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($poste->id); ?>"><?php echo e($poste->Libelle); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
        </div>
      
        <!-- <input class="form-control" name="sexe" type="text"> -->
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
    <strong>Email:</strong>
    <div class="input-group">
        <span class="input-group-addon">
            <i class="fa fa-envelope-o bigger-110"></i>
        </span>
        <input class="form-control" name="email" type="text">
    </div>
  
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
    <strong>Adresse:</strong>
    <input class="form-control" name="adresse" type="text">
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
    <strong>Telephone:</strong>
    <div class="input-group">
        <span class="input-group-addon">
            <i class="ace-icon fa fa-phone"></i>
        </span>
        <input class="form-control" name="telephone" type="text">
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="font-weight:bold;font-size:15px;">
    <strong>Date naissance:</strong>
    <div class="input-group">
        <span class="input-group-addon">
            <i class="fa fa-calendar bigger-110"></i>
        </span>
        <input class="form-control datepicker" name="dateNaissance" type="text">
    </div>
   
</div>
           </div>
</div>

</div>
</form>

<script>
    $(document).ready(function () {

$('.datepicker').datepicker({
                  autoclose: true,
                  format: 'dd/mm/yyyy',
                  todayHighlight: true
              })

              $('#posteId').chosen();
        $("#posteId_chosen").css("width", "100%");

        $('#sexe').chosen();
        $("#sexe_chosen").css("width", "100%");

            });
</script><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/employes/edit.blade.php ENDPATH**/ ?>