<?php if($cmde->produits->count()>0): ?>
<?php $__currentLoopData = $cmde->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmde_produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php

$Quantite= $cmde_produit->pivot->Qte - $cmde_produit->pivot->QteLivre;
?>
<?php if($Quantite!='0'): ?>
<tr class='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>'>
    <td><?php echo e($cmde_produit->Libelle); ?></td>
    <td> <?php echo e(number_format($cmde_produit->unites->where('id',$cmde_produit->pivot->UniteId)->first()->pivot->Qte * $cmde_produit->unites->where('id',$cmde_produit->pivot->UniteId)->first()->pivot->Coef,0,',',' ')); ?> <?php echo e($cmde_produit->unite->Nom); ?></td>
    <td hidden><input class='text-right form-control' name='Produit[]' value='<?php echo e($cmde_produit->id); ?>' type='number'></td>
    <td hidden><input class='text-right form-control' name='Unite[]' value='<?php echo e($cmde_produit->pivot->UniteId); ?>' type='number'></td>
    <td><?php echo e(number_format($cmde_produit->pivot->Qte,0,',',' ')); ?> <?php echo e($cmde_produit->unites->where('id',$cmde_produit->pivot->UniteId)->first()->Nom); ?>(s)</td>
    <td><?php echo e(number_format($cmde_produit->pivot->QteLivre,0,',',' ')); ?> <?php echo e($cmde_produit->unites->where('id',$cmde_produit->pivot->UniteId)->first()->Nom); ?>(s)</td>
    <td><input class='text-right form-control' list='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>' name='Qte[]' min='0' max='<?php echo e($Quantite); ?>' value='<?php echo e($Quantite); ?>' type='number' required /></td>
    <td hidden><input class='text-right form-control' name='OldQteLivre[]' value='<?php echo e($cmde_produit->pivot->QteLivre); ?>' type='number'></td>
    <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this' style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite<?php echo e($cmde_produit->pivot->UniteId); ?><?php echo e($cmde_produit->id); ?>'><span class='fa fa-trash'></span></button></td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/vente/livrs/tableCmde.blade.php ENDPATH**/ ?>