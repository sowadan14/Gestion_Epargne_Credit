

<?php $__env->startSection('content'); ?>
<!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('poste-create')): ?>
<p>
<a class="btn btn-md btn-round btn-primary" href="javascript:void(0)" id="addPoste"><span class=" glyphicon glyphicon-plus"></span> Nouveau</a>
</p>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<?php if($message = Session::get('danger')): ?>
<div class="alert alert-danger">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-stripped data-table">
            <thead>
              <tr>
                <th>N°</th>
                <th>Libellé</th>
                <th class="text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($data) > 0): ?>

				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<!-- <td><img src="<?php echo e(asset('images/' . $row->student_image)); ?>" width="75" /></td> -->
						<td><?php echo e($row->id); ?></td>
						<td><?php echo e($row->Libelle); ?></td>
						<!-- <td><?php echo e($row->student_gender); ?></td> -->
						<td class="text-center">
           
							<a href="javascript:void(0)" data-toggle="tooltip"  data-id="<?php echo e($row->id); ?>" data-original-title="Edit" class="btn btn-default btn-sm showPoste" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('poste-edit')): ?>
              <a href="javascript:void(0)" data-toggle="tooltip"  data-id="<?php echo e($row->id); ?>" data-original-title="Delete" class="btn btn-warning btn-sm editPoste"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('poste-delete')): ?>
              <a href="javascript:void(0)" data-toggle="tooltip"  role="<?php echo e($row->Libelle); ?>"  data-id="<?php echo e($row->id); ?>" data-original-title="Delete" class="btn btn-danger btn-sm deletePoste"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>
              <?php endif; ?>
						</td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<?php else: ?>
				<tr>
					<td colspan="3" class="text-center">No Data Found</td>
				</tr>
			<?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ajaxModel"  data-backdrop="false" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
            <div class="alert alert-danger" style="display:none"></div>
                <form id="posteForm" name="posteForm" method="post" class="form-horizontal">
                   <input type="hidden" name="id" id="id">
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="Libelle"> Libellé </label>
										<div class="col-sm-9">
											<input type="text" id="Libelle" name="Libelle" placeholder=""  class="col-sm-12">
										</div>
									</div>
                  
                </form>
            </div>
            <div class="modal-footer">
            <div class="col-sm-12">
            <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:left;"><i class="ace-icon fa fa-times"></i> Fermer</button>
           <button type="submit" id="CreateForm" value="Create" class="btn btn-primary Saver btn-md btn-round" style="background-color:orange;" >
           <i class="ace-icon fa fa-floppy-o bigger-120"></i> Enregistrer
            </button>
                    </div>
                   
</div>
        </div>
    </div>
</div>


<!-- Show poste -->
<div class="modal fade" id="showAjaxModel"  data-backdrop="false" data-keyboard="false">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="showModelHeading"></h4>
          </div>
          <div class="modal-body">
                 <div class="form-group">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;" for="Libelle"> Libellé: </label>
                  <div class="col-sm-9 forLibelle">
                   
                  </div>
                </div>
          </div>
          <div class="modal-footer">
          <div class="col-sm-12">
          <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:right;"><i class="ace-icon fa fa-times"></i> Fermer</button>
         </div>
                 
</div>
      </div>
  </div>
</div>

<!-- Show poste -->
<div class="modal fade" id="deleteAjaxModel"  data-backdrop="false" data-keyboard="false">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="deleteModelHeading"></h4>
          </div>
          <div class="modal-body">
                 <div class="form-group">
                  <input type="hidden" name="deletePosteid" id="deletePosteid">
                  <div class="col-sm-12 forDelete" style="color:red;font-weight: bold;">
                   
                  </div>
                </div>
          </div>
          <div class="modal-footer">
            <div class="col-sm-12">
              <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:left;"><i class="ace-icon fa fa-times"></i> Fermer</button>
             <button type="submit" id="DeleteForm" value="Create" class="btn btn-danger Saver btn-md btn-round">
             <i class="ace-icon fa fa-trash-o bigger-120"></i> Supprimer
              </button>
                      </div>
                 
</div>
      </div>
  </div>
</div>
</div>

<script type="text/javascript">


  $(function () {

   
      
    /*------------------------------------------
     --------------------------------------------
     Pass Header Token
     --------------------------------------------
     --------------------------------------------*/ 
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
      
    /*------------------------------------------
    --------------------------------------------
    Render DataTable
    --------------------------------------------
    --------------------------------------------*/
    var table = $('.data-table').DataTable({
      "language": {
            "thousands": ' ',
            "decimal": ",",
            "thousands": " ",
            "sProcessing": "Traitement en cours...",
            "sSearch": "Rechercher&nbsp;:",
            "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
            "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
            "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
            "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
            "sInfoPostFix": "",
            "sLoadingRecords": "Chargement en cours...",
            "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
            "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
            "oPaginate": {
                "sFirst": "Premier",
                "sPrevious": "Pr&eacute;c&eacute;dent",
                "sNext": "Suivant",
                "sLast": "Dernier"
            },
            "oAria": {
                "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
            }
        },
        processing: true,
        // serverSide: true,
        "order": [[0, 'desc']],
        // ajax: "<?php echo e(route('postes.index')); ?>",
        // columns: [
        //     // {data: 'DT_RowIndex', name: 'DT_RowIndex'},
        //     {data: 'id', name: 'id'},
        //     {data: 'Libelle', name: 'Libelle'},
        //     {data: 'action', name: 'action', orderable: false, searchable: false,class:'text-center'},
        // ]
    });
      
    /*------------------------------------------
    --------------------------------------------
    Click to Button
    --------------------------------------------
    --------------------------------------------*/
    $('#addPoste').click(function () {
      jQuery('.alert-danger').html('');

        $('#CreateForm').removeClass("btn-warning").addClass('btn-primary');
        $('#id').val('');
        $('#posteForm').trigger("reset");
        $('#modelHeading').html("<i class='glyphicon glyphicon-plus'></i> Nouveau poste");
        $('#ajaxModel').modal('show');
    });
      
    /*------------------------------------------
    --------------------------------------------
    Click to Edit Button
    --------------------------------------------
    --------------------------------------------*/
    $('body').on('click', '.editPoste', function () {
      jQuery('.alert-danger').html('');

      var poste_id = $(this).data('id');
      $.get("<?php echo e(route('postes.index')); ?>" +'/' + poste_id +'/edit', function (data) {
          $('#modelHeading').html("<i class='glyphicon glyphicon-edit'></i> Modification d'un poste");
          $('#CreateForm').removeClass('btn-primary').addClass("btn-warning");
          $('#ajaxModel').modal('show');
          $('#id').val(data.id);
          $('#Libelle').val(data.Libelle);
          $('#DateCreation').val(data.DateCreation);
          $('#EntrepriseId').val(data.EntrepriseId);
      })
    });

    $('body').on('click', '.showPoste', function () {
      jQuery('.alert-danger').html('');

      var poste_id = $(this).data('id');
      $.get("<?php echo e(route('postes.index')); ?>" +'/' + poste_id +'/edit', function (data) {
          $('#showModelHeading').html("<i class='ace-icon fa fa-eye'></i> Details d'un poste");
          $('#showAjaxModel').modal('show');
          $('.forLibelle').html(data.Libelle);
      })
    });
   
      
    /*------------------------------------------
    --------------------------------------------
    Create Product Code
    --------------------------------------------
    --------------------------------------------*/
    $('#CreateForm').click(function (e) {
        e.preventDefault();
        $.ajax({
          data: $('#posteForm').serialize(),
          url: "<?php echo e(route('postes.store')); ?>",
          type: "POST",
          // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          dataType: 'json',
          success: function (data) {
              if(data.errors)
                  	{
                  		jQuery('.alert-danger').html('');

                  		jQuery.each(data.errors, function(key, value){
                  			jQuery('.alert-danger').show();
                  			jQuery('.alert-danger').append('<li>'+value+'</li>');
                  		});
                  	}
                  	else
                  	{
                      $('#posteForm').trigger("reset");
              $('#ajaxModel').modal('hide');
              window.location=data.url;
                  	}
           
          },
          error: function (data) {
            
          }
      });
    });

    
    $('body').on('click', '.deletePoste', function () {
          var id = $(this).data('id');
          var Libelle = $(this).attr('role');
          $('#deleteModelHeading').html("<i class='ace-icon fa fa-trash-o bigger-120'></i> Suppression d'un poste");
          $('#deleteAjaxModel').modal('show');
          $("#deletePosteid").val(id);
          $('.forDelete').html("Voulez-vous vraiment supprimer le poste: "+Libelle+"?");
    
    });
      
    /*------------------------------------------
    --------------------------------------------
    Delete Product Code
    --------------------------------------------
    --------------------------------------------*/
    $('#DeleteForm').click(function (e) {
        e.preventDefault();
     
        var id = $("#deletePosteid").val();
        
        $.ajax({
type:"POST",
url: "<?php echo e(url('deletePoste')); ?>",
data: { id: id },
dataType: 'json',
success: function(data){
  window.location=data.url;
}
});
    });
       
  });
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager30012023\MyShopManager\resources\views/postes/index.blade.php ENDPATH**/ ?>