
<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type=file]::file-selector-button {
        margin-right: 5px;
        border: none;
        background: #084cdf;
        padding: 10px 5px;
        border-radius: 10px;
        color: #fff;
        cursor: pointer;
        transition: background .2s ease-in-out;
    }

    input[type=file]::file-selector-button:hover {
        background: #0d45a5;
    }



    .drop-container {
        position: relative;
        display: flex;
        margin: 10px;
        gap: 10px;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: inherit;
        padding: 5px;
        border-radius: 10px;
        border: 2px dashed #555;
        color: #444;
        cursor: pointer;
        transition: background .2s ease-in-out, border .2s ease-in-out;
    }

    .drop-container:hover {
        background: #eee;
        border-color: #111;
    }

    .drop-container:hover .drop-title {
        color: #222;
    }

    .drop-title {
        color: #444;
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        transition: color .2s ease-in-out;
    }

    td,
    th {
        padding: 5px;
    }

    .innerTd {
        width: 100px;
    }

    .active {
        background-color: aqua;
    }

    #navMenus {
        list-style: none;
    }

    li {
        cursor: pointer;
        margin-bottom: 5px;
    }

    ul {
        margin-left: 0px;
    }

    .tableRecap td {
        white-space: nowrap;
        border-top: 0px solid #ddd;
    }

    .tableRecap td:first-child {

        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    .tableRecap td:last-child {
        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    .tableRecap>tbody>tr>td,
    .tableRecap>tbody>tr>th,
    .tableRecap>tfoot>tr>td,
    .tabtableRecaple>tfoot>tr>th,
    .tableRecap>thead>tr>td,
    .tableRecap>thead>tr>th {
        padding: 2px;
        line-height: 1.42857143;
        vertical-align: middle;
        border-top: 1px solid #ddd0;
    }

    .row {
        margin-bottom: 2px;
    }

</style>

<?php echo Form::open(array('route' => 'acmdes.store','method'=>'POST')); ?>


<div class="EnteteContent">
    <div class="row">

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
            <i class=" icon-cart31 bigger-130"></i> Gestion commande fournisseur
        </div>

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
            Création d'une commande fournisseur
        </div>
    </div>
    <hr class="hrEntete">
    <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

    <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:0 25px 0 25px;">

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Fournisseur</strong>
                        <div>
                            <select name="FournisseurId" id="FournisseurId">
                                <option value="">Séléctionner un fournisseur</option>
                                <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fournisseur->id); ?>" <?php echo e((old('FournisseurId')==$fournisseur->id) ?
                                    'selected' : ''); ?>>
                                    <?php echo e($fournisseur->Nom); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('FournisseurId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('FournisseurId')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Mode paiement</strong>
                        <div>
                            <select name="ModePaiementId" id="ModePaiementId">
                                <option value="">Séléctionner un mode paiement</option>
                                <?php $__currentLoopData = $modepaiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modepaiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($modepaiement->id); ?>" <?php echo e((old('ModePaiementId')==$modepaiement->id) ?
                                    'selected' : ''); ?>>
                                    <?php echo e($modepaiement->Nom); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('ModePaiementId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('ModePaiementId')); ?></span>
                        <?php endif; ?>
                    </div>


                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Compte</strong>
                        <div>
                            <select name="CompteId" id="CompteId">
                                <option value="">Séléctionner un compte</option>
                                <?php $__currentLoopData = $comptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($compte->id); ?>" <?php echo e((old('CompteId')==$compte->id) ?
                                    'selected' : ''); ?>>
                                    <?php echo e($compte->Libelle); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('CompteId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CompteId')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Référence</strong>
                        <input class="form-control" name="Reference" value="<?php echo e(old('Reference',generateCmdeAchat())); ?>" type="text">

                        <?php if($errors->has('Reference')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Reference')); ?></span>
                        <?php endif; ?>
                    </div>
                    </div>
                  <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Date commande</strong>
                        <input class="form-control datepicker text-center" name="DateAchat" value="<?php echo e(old('DateAchat')); ?>" type="text">
                        <?php if($errors->has('DateAchat')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateAchat')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                        <strong>Date réception</strong>
                        <input class="form-control datepicker text-center" name="DateReception" value="<?php echo e(old('DateReception')); ?>" type="text">
                        <?php if($errors->has('DateReception')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateReception')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if(Auth()->user()->entreprise->AvoirFrManager): ?>
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">

                        <label style="margin-top:25px;"><input name="IsAvoir" type="checkbox">
                            <strong> Mettre la monnaie en avoir</strong></label>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>


    </div>
</div>

<div class="EnteteContent">
    <div class="form-group row">
        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 table-responsive" style="overflow-y: scroll;max-height:250px;font-weight:bold;font-size:80%;">
            Produits:
            <!-- <input type="text" id="myInput" class="form-control FilterSearch"> -->

            <ul id="navMenus">
                <li>
                    <div><input class="FilterSearch form-control" type="text" /></div>
                </li>
                <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li id="<?php echo e($produit->id); ?>" class="SelectProduit selector"><?php echo e($produit->Libelle); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3" style="padding:5px;">
                    <div>
                        <select name="UniteId" id="UniteId">
                            <option value="">Séléctionner une unité</option>
                            <!-- <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unite->id); ?>" <?php echo e((old('UniteId')==$unite->id) ? 'selected' : ''); ?>>
                                <?php echo e($unite->Nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                        </select>
                    </div>
                    <?php if($errors->has('UniteId')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('UniteId')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9" style="margin-top:5px;">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bolder"> 
                <?php if(Auth()->user()->entreprise->AvoirFrManager): ?>

                        <input class="form-control hidden" name="MontantAvoir" id="MontantAvoir" val="0" type="text">
                        <label><input name="PaidWithAvoir" id="PaidWithAvoir" type="checkbox">
                            <strong> Payer avec avoir (<span class="avoir">0</span>)</strong></label>
                            <?php endif; ?>
                    </div>
                  
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 bolder">Remise globale:</div>
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"><input class="form-control text-right remiseglobale"  id="Remiseglobale" name="Remiseglobale" value="<?php echo e(old('Remiseglobale',0)); ?>" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;"></div>
                    
                        <input hidden class="form-control text-right MontantPaye hidden"  name="MontantPaye" value="0" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;">
                   
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="overflow-y: scroll;max-height:180px;">
                    <table class="table table-bordered " id="TableOfData"  style="font-size:90%;">
                        <tr style="background:#006fcf;color:#FFF;font-weight:bold;">

                            <td hidden>Unité</td>
                            <td>Produit</td>
                            <td>Unité</td>
                            <td class="text-right innerTd">Qté cmdée</td>
                            <td class="text-right innerTd">Qté reçue</td>
                            <td class="text-right innerTd">Prix Achat</td>
                            <td class="text-right innerTd">Remise (%)</td>
                            <td class="text-right innerTd">TVA (%)</td>
                            <td class="text-right">Montant TTC</td>
                            <td class="text-center">Action</td>
                        </tr>
                        <tbody id="DetailsUnites">

                        </tbody>
                    </table>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="font-size:80%;">

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>TOTAL HT :</strong> <span class="mtht">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>TOTAL REMISE :</strong> <span class="mtremise">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>TOTAL TVA :</strong> <span class="mttva">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>TOTAL COMMANDE :</strong> <span class="mtttc">0</span>
                            </div>
                        </div>

                        <?php if(Auth()->user()->entreprise->AvoirFrManager): ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>FACTURE :</strong> <span class="mtfacture">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>AVOIR :</strong> <span class="mtavoir">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3" style="background-color:#cad7fa;">
                                <strong>RESTE A PAYER :</strong> <span class="resteapayer">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                    <strong>MT REMIS :</strong>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                    <input class="form-control text-right" id="MontantRemis" name="MontantRemis" value="<?php echo e(old('MontantRemis',0)); ?>" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">

                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">

                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">

                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                    <strong>MONNAIE :</strong>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                    <input class="form-control text-right" id="Monnaie" name="Monnaie" readonly="readonly" value="0" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;">
                                </div>
                            </div>
                        </div>

                        <?php else: ?>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <strong>FACTURE :</strong> <span class="mtfacture">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3" style="background-color:#cad7fa;">
                                <strong>RESTE A PAYER :</strong> <span class="resteapayer">0</span>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                    <strong>MT REMIS :</strong>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                    <input class="form-control text-right" id="MontantRemis" name="MontantRemis" value="<?php echo e(old('MontantRemis',0)); ?>" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                    <strong>MONNAIE :</strong>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                    <input class="form-control text-right" id="Monnaie" name="Monnaie" readonly="readonly" value="0" type="number" style="min-width:100px;height:23px;background:gainsboro;border: 2px solid maroon;">
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="form-group" style="float:right;margin:15px;">
    <a href="<?php echo e(url('/achat/acmdes')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste commandes fournisseur</span></a>

    <button type="submit" value="Create" class="btn btn-primary btn-sm bolder">
        <i class="glyphicon glyphicon-plus"></i> Créer
    </button>
</div>
<?php echo Form::close(); ?>



<script type="text/javascript">
    $(document).ready(function() {

        localStorage.setItem("myclass", 'achatcmde');
        localStorage.setItem("father", 'achat');

        $(document).on("input propertychange paste change", '.FilterSearch', function(e) {
            var value = $(this).val().toLowerCase();
            $(this).parents("ul").find('li:not(li:first-of-type)').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });

        });

        function toNumberFormat(value) {
            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        }

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })

        $(document).on('click', '.remove_this', function() {
            var DivName = $(this).attr("name");
            $("." + DivName).remove();
            CalculeSumChamps("TableOfData");
            return false;
        });



        $('#ModePaiementId').chosen();
        $("#ModePaiementId_chosen").css("width", "100%");

        $('#FournisseurId').chosen();
        $("#FournisseurId_chosen").css("width", "100%");

        $('#UniteId').chosen();
        $("#UniteId_chosen").css("width", "100%");

        $('#CompteId').chosen();
        $("#CompteId_chosen").css("width", "100%");

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $("#navMenus").on('click', 'li.selector', function() {
            var produitId = $(this).attr('id');
            $("#navMenus li.active").removeClass("active");
            // adding classname 'active' to current click li 
            $(this).addClass("active");
            if (produitId != "") {
                $('#UniteId').empty();
                $("#UniteId").append("<option value=''>Séléctionnez une unité</option>");
                $.ajax({
                    url: "<?php echo e(url('achat/acmdes/getUnites')); ?>",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        id: produitId
                    },
                    success: function(data) {
                        $.each(data.split('|'), function(index, value) {
                            if (value != "") {
                                $("#UniteId").append("<option value='" + value.split(
                                        '~')[0] + "' " + value.split('~')[2] + ">" +
                                    value.split('~')[1] + "</option>");
                            }
                        });
                        $('#UniteId').trigger("chosen:updated");
                        let UniteId = $('#UniteId').val();
                        setLineProduit(produitId, UniteId);
                    }
                });
            }


        });


        function setLineProduit(ProduitId, UniteId) {
            if (ProduitId != "" && UniteId != "") {
                if ($('.PUnite' + UniteId.split('/')[0] + "" + ProduitId).length < 1) {
                    $("#DetailsUnites").append("<tr  class='PUnite" + UniteId.split('/')[0] + "" + ProduitId + "'  style='background-color:aqua;'>\
                      <td>" + $("#navMenus li.active").html() + "</td>\
                      <td>" + $('#UniteId option:selected').text() + "</td>\
                      <td hidden><input class='text-right form-control' name='Produit[]' value='" + ProduitId + "'  type='number'></td>\
                      <td hidden><input class='text-right form-control' name='Unite[]' value='" + UniteId.split('/')[
                            0] + "'  type='number'></td>\
                      <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='Qte[]' min='0' value='0' type='number' required /></td>\
                        <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='QteRecus[]' min='0' value='0' type='number' required /></td>\
                     <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='PrixAchat[]' value='" + UniteId.split('/')[1] + "'  min='0' type='number' required /></td>\
                      <td><input class='text-right form-control' list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='Remise[]'  value='0'  min='0' type='number' required /></td>\
                      <td><input class='text-right form-control'  list='PUnite" + UniteId.split('/')[0] + "" +
                        ProduitId + "'  name='TVA[]'  value='<?php echo e(auth()->user()->entreprise->TVA); ?>'  min='0' type='number' required /></td>\
                      <td  class='text-right'>0</td>\
                      <td hidden><input class='text-right form-control' name='MontantTTC[]'  type='number'></td>\
                      <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this'\
                      style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite" + UniteId.split(
                            '/')[0] + "" + ProduitId + "'><span class='fa fa-trash'></span></button></td>\
                      </tr>");
                }
            }

        }

        function CalculeSumChamps(tableID) {
            var montantht = 0;
            var montantremise = 0;
            var montanttva = 0;
            var montantttc = 0;

            var montanthtRecu = 0;
            var montantremiseRecu = 0;
            var montanttvaRecu = 0;
            var montantttcRecu = 0;


            var qte = 0;
            $("#" + tableID + " tbody#DetailsUnites tr").each(function() {
                var Qte = parseFloat(($(this).find("td").eq(4).find("input").val()).replace(/ /g, ''));
                var Qterecu = parseFloat(($(this).find("td").eq(5).find("input").val()).replace(/ /g, ''));
                var Prix = parseFloat(($(this).find("td").eq(6).find("input").val()).replace(/ /g, ''));
                var remise = parseFloat(($(this).find("td").eq(7).find("input").val()).replace(/ /g, ''));
                var tva = parseFloat(($(this).find("td").eq(8).find("input").val()).replace(/ /g, ''));


                var mtht = parseFloat(Qte * Prix);
                var mtremise = Math.round(parseFloat((mtht * remise) / 100));
                var mttva = Math.round(parseFloat(((mtht * tva) / 100)));

                var mthtRecu = parseFloat(Qterecu * Prix);
                var mtremiseRecu = Math.round(parseFloat((mthtRecu * remise) / 100));
                var mttvaRecu = Math.round(parseFloat(((mthtRecu * tva) / 100)));


                montantht += mtht;
                montantremise += mtremise;
                montanttva += mttva;
                montantttc += parseFloat(parseFloat(mtht) + parseFloat(mttva) - parseFloat(mtremise));

                montanthtRecu += mthtRecu;
                montantremiseRecu += mtremiseRecu;
                montanttvaRecu += mttvaRecu;
                montantttcRecu += parseFloat(parseFloat(mthtRecu) + parseFloat(mttvaRecu) - parseFloat(mtremiseRecu));
            });

            if(montantttcRecu<=0)
            {
                $("#Remiseglobale").val(0);
                $("#Remiseglobale").attr('readonly',true);
                $("input[name='IsAvoir']").attr('checked',false);
                $("input[name='PaidWithAvoir']").attr('checked',false);
                $("#MontantRemis").val(0);
                $("#MontantRemis").attr('readonly',true);
                $("#Monnaie").val(0);
            }
            else
            {
                $("#Remiseglobale").attr('readonly',false);
                $("#MontantRemis").attr('readonly',false); 
            }


            var remiseglobale = $(".remiseglobale").val();
            var montantremis = $("#MontantRemis").val();
            $(".mtht").html(toNumberFormat(montantht));
            $(".mtremise").html(toNumberFormat(montantremise + parseFloat(remiseglobale)));
            $(".mttva").html(toNumberFormat(montanttva));
            $(".mtttc").html(toNumberFormat(montantttc - parseFloat(remiseglobale)));
            $(".MontantPaye").val(montantttcRecu - parseFloat(remiseglobale));
            $(".mtfacture").html(toNumberFormat(montantttcRecu - parseFloat(remiseglobale)));

            if ($('#PaidWithAvoir').prop("checked") == true) {
                var montantavoir = $("#MontantAvoir").val();
                $(".mtavoir").html(toNumberFormat(parseFloat(montantavoir).toFixed(0)));
                var resteapayer = montantttcRecu - parseFloat(remiseglobale);
                var montantpayer = parseFloat(montantremis) + parseFloat(montantavoir);

                if (montantpayer >= parseFloat(resteapayer)) {
                    $(".resteapayer").html(0);
                    $("#Monnaie").val(parseFloat(montantpayer) - parseFloat(resteapayer))
                    // $("#MontantRemis").val(0);
                } else {
                    $(".resteapayer").html(toNumberFormat(montantttcRecu - parseFloat(remiseglobale) - parseFloat(montantpayer)));
                    // $("#MontantRemis").val(montantttc - parseFloat(remiseglobale) - parseFloat(montantpayer));
                    $("#Monnaie").val(0)
                }

            } else {
                // $("#MontantAvoir").val(0);
                $(".mtavoir").html(0);
                var resteapayer = montantttcRecu - parseFloat(remiseglobale);
                var montantpayer = parseFloat(montantremis);
                if (montantpayer >= parseFloat(resteapayer)) {
                    $(".resteapayer").html(0);
                    $("#Monnaie").val(parseFloat(montantpayer) - parseFloat(resteapayer))
                } else {
                    // $("#MontantRemis").val(montantttc - parseFloat(remiseglobale) - parseFloat(montantpayer));
                     $(".resteapayer").html(toNumberFormat(montantttcRecu - parseFloat(remiseglobale) - parseFloat(montantpayer)));
                    $("#Monnaie").val(0)
                }
            }

        }

        function CalculeSumPayerChamps(tableID) {
            var montantht = 0;
            var montantremise = 0;
            var montanttva = 0;
            var montantttc = 0;
            var qte = 0;
            $("#" + tableID + " tbody#DetailsUnites tr").each(function() {
                var Qte = parseFloat(($(this).find("td").eq(5).find("input").val()).replace(/ /g, ''));
                var Prix = parseFloat(($(this).find("td").eq(6).find("input").val()).replace(/ /g, ''));
                var remise = parseFloat(($(this).find("td").eq(7).find("input").val()).replace(/ /g, ''));
                var tva = parseFloat(($(this).find("td").eq(8).find("input").val()).replace(/ /g, ''));


                var mtht = parseFloat(Qte * Prix);
                var mtremise = Math.round(parseFloat((mtht * remise) / 100));
                var mttva = Math.round(parseFloat(((mtht * tva) / 100)));

                montantht += mtht;
                montantremise += mtremise;
                montanttva += mttva;
                montantttc += parseFloat(parseFloat(mtht) + parseFloat(mttva) - parseFloat(mtremise));
            });
            var remiseglobale = $(".remiseglobale").val();
            $(".MontantPaye").val(montantttc - parseFloat(remiseglobale));

        }


        $('#UniteId').on('change', function(e) {
            let ProduitId = $("#navMenus li.active").attr('id');
            let UniteId = $('#UniteId').val();
            setLineProduit(ProduitId, UniteId);
        });


        function getFrAvoir() {
            let FournisseurId = $("#FournisseurId").val();
            if (FournisseurId != "") {
                $.ajax({
                    url: "<?php echo e(url('achat/acmdes/getFrAvoir')); ?>",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        id: FournisseurId
                    },
                    success: function(data) {
                        $("#MontantAvoir").val(data);
                        $(".avoir").html(toNumberFormat(parseFloat(data).toFixed(0)));
                    }
                });
            }
        }

        $('#FournisseurId').on('change', function(e) {
            if(<?php echo e(Auth::user()->entreprise->AvoirFrManager); ?>==true)
            {
                getFrAvoir();
            }
          
        });

        
        $('#MontantRemis').on('change', function(e) {
            if ($(this).val() == "") {
                $(this).val(0);
            }
            CalculeSumChamps("TableOfData");
        });



        $('#PaidWithAvoir').on('change', function(e) {
            CalculeSumChamps("TableOfData");
        });



        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Remiseglobale"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            CalculeSumChamps("TableOfData");
        });


        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Qte[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));

            $("#TableOfData tbody#DetailsUnites tr." + $(this).attr('list')).find("td").eq(5).find("input").val(Qte);
            CalculeSumChamps("TableOfData");
            $("#TableOfData tbody tr." + id).css('background-color', '#FFF');
        });

        // $('input[name="Qte[]"]').on('change', function(e) {
        $(document).on("change", 'input[name="Remise[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));

            CalculeSumChamps("TableOfData");
            $("#TableOfData tbody tr." + id).css('background-color', '#FFF');
        });


        $(document).on("change", 'input[name="QteRecus[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            CalculeSumChamps("TableOfData");
            $("#TableOfData tbody tr." + id).css('background-color', '#FFF');
        });

        $(document).on("change", 'input[name="PrixAchat[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));
            CalculeSumChamps("TableOfData");
            $("#TableOfData tbody tr." + id).css('background-color', '#FFF');
        });

        $(document).on("change", 'input[name="TVA[]"]', function() {
            if ($(this).val() == "") {
                $(this).val(0);
            }

            var id = $(this).attr("list");
            Qte = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(4).find("input").val())
                .replace(/ /g, ''));
            Prix = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(6).find("input").val())
                .replace(/ /g, ''));
            remise = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(7).find("input").val())
                .replace(/ /g, ''));
            tva = parseFloat(($("#TableOfData tbody tr." + id).find("td").eq(8).find("input").val())
                .replace(/ /g, ''));

            MontantHT = Qte * Prix;
            Remise = Math.round((MontantHT * remise / 100).toFixed(0));
            TVA = Math.round((MontantHT * tva) / 100);
            MontantTTC = parseFloat(MontantHT) + parseFloat(TVA) - parseFloat(Remise);
            $("#TableOfData tbody tr." + id).find("td").eq(10).find("input").val(MontantTTC);
            $("#TableOfData tbody tr." + id).find("td").eq(9).html(toNumberFormat(MontantTTC));
            CalculeSumChamps("TableOfData");
            $("#TableOfData tbody tr." + id).css('background-color', '#FFF');
        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/achat/acmdes/create.blade.php ENDPATH**/ ?>