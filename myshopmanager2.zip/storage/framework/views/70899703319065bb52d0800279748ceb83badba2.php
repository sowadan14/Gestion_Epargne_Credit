<form id="roleForm" name="roleForm" method="post" class="form-horizontal">
<!-- <input name="_method" type="hidden" value="PATCH"> -->
                <input type="hidden" name="id" id="id" value="<?php echo e($role->id); ?>">
                <div style="overflow-y:auto;max-height:450px;margin:15px;">
<div class="form-group row">
 
 <div class="col-xs-12 col-sm-12 col-md-11 col-lg-11" style="padding-left:25px;font-weight:bold;font-size:15px;">
         <strong>Libellé:</strong>
         <?php echo Form::text('name', $role->name, array('class' => 'form-control')); ?>

 </div>
 <br>
 <div class="col-xs-12 col-sm-12 col-md-12">
     <div class="">
       <br>
         <div class="form-group row" style="padding-left:15px;">
           <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
               <p style="font-weight:bold;font-size:15px;margin-bottom: 0.1rem">Permissions: <label style="color:#313cba;"><input type="checkbox" id="checkAllUser" /> Choisir Tous</label></p>
           </div>
       </div>
         <div>
           <?php $__currentLoopData = $numParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numParent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-lg-4 col-md-4 col-sm-12">
           <div class="col-xs-11 label label-lg label-info  arrowed-right">
           <label style="text-align:left"> <?php echo e(Form::checkbox('Parent', $numParent, false, array('class' => 'name','id'=>'Parent','role'=>$permissions->where('NumParent',$numParent)->first()->TypeParent))); ?> <?php echo e($permissions->where('NumParent',$numParent)->first()->Parent); ?></label>
           </div>
           <div style="margin-bottom:10px;margin-top:28px;">
             <?php $__currentLoopData = $permissions->where('NumParent',$numParent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
           <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name','class' => $value->TypeParent))); ?>

               <?php echo e($value->Libelle); ?> <?php echo $value->Lien; ?> </label>
           <br/>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
        
     </div>
 </div>
 
</div>
</div>        
             </form><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/roles/edit.blade.php ENDPATH**/ ?>