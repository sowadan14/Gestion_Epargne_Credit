
    
<?php $__env->startSection('content'); ?>
<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
	<?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
	<div class="EnteteContent">
<div class="form-group" style="padding-bottom:15px;">

	<div class="col-sm-12 col-xs-12 col-md-6 col-lg-6" style="font-size:150%;font-weight: bold;margin-top:-5px;">
		Gestion des postes
	</div>

	<div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">
		<div class="btn-group dropleft" style="float: right;">
			<button data-toggle="dropdown" class="btn btn-white btn-xs dropdown-toggle" aria-expanded="false">
				<i class="glyphicon glyphicon-align-justify"></i> Option
				<span class="ace-icon fa fa-caret-down icon-on-right"></span>
			</button>

			<ul class="dropleft dropdown-menu dropdown-inverse">
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createposte')): ?>
				<li>
					<a href="<?php echo e(route('postes.create')); ?>" id="addPostegg"><span
							class="glyphicon glyphicon-plus blue"></span> Nouveau poste</a>
				</li>
				<?php endif; ?>

				<li>
					<a href="#" id="dd"><span class=" glyphicon glyphicon-file"></span> Exporter la séléction en
						excel</a>
				</li>
			</ul>
		</div>
	</div>
</div>
		<!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->
		
		<?php if($message = Session::get('success')): ?>
		<div class="alert alert-success">
			<p><?php echo e($message); ?></p>
		</div>
		<?php endif; ?>

		<?php if($message = Session::get('danger')): ?>
		<div class="alert alert-danger">
			<p><?php echo e($message); ?></p>
		</div>
		<?php endif; ?>
		<!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
		<div class="row">
        <form id="posteForm" name="posteForm" method="post" class="form-horizontal">
                   <input type="text" name="poste_id" id="poste_id">
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="Libelle"> Libellé </label>
										<div class="col-sm-9">
											<input type="text" id="Libelle" name="Libelle" placeholder=""  class="col-sm-12">
										</div>
									</div>
                  
                </form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/postes/create.blade.php ENDPATH**/ ?>