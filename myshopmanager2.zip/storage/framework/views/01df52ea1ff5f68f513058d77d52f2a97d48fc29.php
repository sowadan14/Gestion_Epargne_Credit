
<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type=file]::file-selector-button {
        margin-right: 5px;
        border: none;
        background: #084cdf;
        padding: 10px 5px;
        border-radius: 10px;
        color: #fff;
        cursor: pointer;
        transition: background .2s ease-in-out;
    }

    input[type=file]::file-selector-button:hover {
        background: #0d45a5;
    }

    .drop-container {
        position: relative;
        display: flex;
        margin: 10px;
        gap: 10px;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: inherit;
        padding: 5px;
        border-radius: 10px;
        border: 2px dashed #555;
        color: #444;
        cursor: pointer;
        transition: background .2s ease-in-out, border .2s ease-in-out;
    }

    .drop-container:hover {
        background: #eee;
        border-color: #111;
    }

    .drop-container:hover .drop-title {
        color: #222;
    }

    .drop-title {
        color: #444;
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        transition: color .2s ease-in-out;
    }

    td,
    th {
        padding: 5px;
    }

    .innerTd {
        width: 100px;
    }

    .active {
        background-color: aqua;
    }

    #navMenus {
        list-style: none;
    }

    li {
        cursor: pointer;
        margin-bottom: 5px;
    }

    ul {
        margin-left: 0px;
    }
</style>

<?php echo Form::model($livr, ['method' => 'PATCH','route' => ['livrs.update', $livr->id]]); ?>


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
        <div class="EnteteContent">
            <div class="row">

                <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                    <i class=" fa fa-truck"></i> Gestion livraisons
                </div>

                <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                    Modification d'une livraison
                </div>
            </div>
            <hr class="hrEntete">
            <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

            <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
            <div class="row">
                <input type="text" name="id" id="id" value="<?php echo e($livr->id); ?>" hidden>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="form-group row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <strong>Réference commande</strong>
                                <div>
                                    <select name="CommandId" id="CommandId">
                                        <?php $__currentLoopData = $Cmdes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cmde): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($Cmde->id); ?>" <?php echo e(($Cmde->id==$cmde->id) ? 'selected' : ''); ?> <?php echo e((old('CommandId')==$Cmde->id) ? 'selected' : ''); ?>> <?php echo e($Cmde->Reference); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php if($errors->has('CommandId')): ?>
                                <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CommandId')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <strong>Référence</strong>
                                <input class="form-control" name="Reference" value="<?php echo e(old('Reference',$livr->Reference)); ?>" type="text">
                                <?php if($errors->has('Reference')): ?>
                                <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Reference')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <strong>Date livraison</strong>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-calendar bigger-110"></i>
                                    </span>
                                    <input class="form-control datepicker" name="DateLivraison" value="<?php echo e(old('DateLivraison',\Carbon\Carbon::parse($livr->DateLivraison)->format('d/m/Y'))); ?>" type="text" required>
                                </div>
                                <?php if($errors->has('DateLivraison')): ?>
                                <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateLivraison')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <strong>Note</strong>
                                <textarea class="form-control" name="Note" value="<?php echo e(old('Note')); ?>" type="text"></textarea>
                                <?php if($errors->has('Note')): ?>
                                <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Note')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>


        
<div class="EnteteContent">
    <div class="form-group row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="overflow-y: scroll;max-height:200px;">
            <table class="table table-bordered" id="TableOfData" style="font-size:80%;">
                <tr style="background:#006fcf;color:#FFF;font-weight:bold;">

                    <td hidden>Unité </td>
                    <td>Produit</td>
                    <td>Unité</td>
                    <td class="text-right innerTd">Qté à livrer</td>
                    <td class="text-center">Action</td>
                </tr>
                <tbody id="DetailsUnites">
                    <?php if($livr->produits->count()>0): ?>

                    <?php $__currentLoopData = $livr->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livr_produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $cmde->produits->where('id',$livr_produit->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmde_produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($livr_produit->pivot->UniteId==$cmde_produit->pivot->UniteId): ?>

                    <?php
                    $Quantite= $cmde_produit->pivot->Qte - $cmde_produit->pivot->QteLivre + $livr_produit->pivot->Qte;
                    ?>

                    <?php if($Quantite!='0'): ?>
                    <tr class='PUnite<?php echo e($livr_produit->pivot->UniteId); ?><?php echo e($livr_produit->id); ?>'>
                        <td><?php echo e($livr_produit->Libelle); ?></td>
                        <td><?php echo e($livr_produit->unites->where('id',$livr_produit->pivot->UniteId)->first()->Nom); ?></td>
                        <td hidden><input class='text-right form-control' name='Produit[]' value='<?php echo e($livr_produit->id); ?>' type='number'></td>
                        <td hidden><input class='text-right form-control' name='Unite[]' value='<?php echo e($livr_produit->pivot->UniteId); ?>' type='number'></td>
                        <td><input class='text-right form-control' list='PUnite<?php echo e($livr_produit->pivot->UniteId); ?><?php echo e($livr_produit->id); ?>' name='Qte[]' min='0' max='<?php echo e($Quantite); ?>' value='<?php echo e($Quantite); ?>' type='number' required /></td>
                        <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this' style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite<?php echo e($livr_produit->pivot->UniteId); ?><?php echo e($livr_produit->id); ?>'><span class='fa fa-trash'></span></button></td>
                    </tr>
                    <?php endif; ?>
                    <?php break; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
        <div class="EnteteContent">
            <div class="row">
                <div class="col-sm-12 col-xs-12 col-md-12 col-lg-12">
                    Détails de la commande
                </div>
            </div>
            <hr class="hrEntete">
            <div class=" detailsCmde">
                <table>
                    <tr>
                        <td>
                            <strong>Date commande:</strong> <?php echo e(\Carbon\Carbon::parse($cmde->DateAchat)->format('d/m/Y')); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Montant TTC:</strong> <?php echo e(number_format($cmde->MontantTTC,0,',',' ')); ?> <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Client:</strong> <?php echo e($cmde->client->Nom); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Status livraison:</strong>

                            <?php

                            if(($cmde->MontantLivre/$cmde->MontantTTC)*100 < 99.9999 && ($cmde->MontantLivre/$cmde->MontantTTC)*100 > 99.9)
                                {
                                $StatusLivraison=99;
                                }
                                else
                                {
                                $StatusLivraison=round(($cmde->MontantLivre/$cmde->MontantTTC)*100);
                                }
                                ?>

                                <div class="progress pos-rel" data-percent="<?php echo e($StatusLivraison); ?>%">
                                    <div class="progress-bar" style="width:<?php echo e($StatusLivraison); ?>%;"></div>
                                </div>

                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>





<div class="form-group" style="float:right;margin:15px;">
    <a href="<?php echo e(url('/vente/livrs')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des livraisons</span></a>

    <button type="submit" value="Create" class="btn btn-warning btn-sm bolder">
        <i class="glyphicon glyphicon-edit"></i> Modifier
    </button>
</div>
<?php echo Form::close(); ?>



<script type="text/javascript">
    $(document).ready(function() {


        localStorage.setItem("myclass", 'livr');
        localStorage.setItem("father", 'vente');


        $(document).on('keyup', 'input[name="Qte[]"]', function() {
            var _this = $(this);
            var min = parseInt(_this.attr('min')) || 0; // if min attribute is not defined, 1 is default
            var max = parseInt(_this.attr('max')) || 100; // if max attribute is not defined, 100 is default
            var val = parseInt(_this.val()) || (min - 1); // if input char is not a number the value will be (min - 1) so first condition will be true
            if (val < min)
                _this.val(min);
            if (val > max)
                _this.val(max);
        });

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })

        $(document).on('click', '.remove_this', function() {
            var DivName = $(this).attr("name");
            $("." + DivName).remove();
            CalculeSumChamps("TableOfData");
            return false;
        });



        $(document).on('change', '#CommandIdhhhh', function() {
            var id = $("#CommandId").val();
            $("#CreateForm").attr('action', '/vente/livrs/Addlivrt/' + id);
            event.preventDefault();
            $("#CreateForm").submit();
        });



        $('#CommandId').chosen();
        $("#CommandId_chosen").css("width", "100%");


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });




        $(document).on('change', '#CommandId', function() {
            var AchatId = $("#CommandId").val();
            if (AchatId != "") {
                $.ajax({
                    url: "<?php echo e(url('vente/livrs/getDetailsRecept')); ?>",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        id: AchatId
                    },
                    success: function(data) {
                        $('.detailsCmde').html(data.htmlDetailsCmde);
                        $('#DetailsUnites').empty();
                        // $("#TableOfData tbody").append(data.htmlTable);
                        $('#DetailsUnites').append(data.htmlTable);
                    },
                });

            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/vente/livrs/edit.blade.php ENDPATH**/ ?>