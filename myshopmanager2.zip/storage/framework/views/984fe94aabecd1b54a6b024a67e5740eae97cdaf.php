
<?php $__env->startSection('content'); ?>

<style type="text/css">
input[type=file]::file-selector-button {
    margin-right: 5px;
    border: none;
    background: #084cdf;
    padding: 10px 5px;
    border-radius: 10px;
    color: #fff;
    cursor: pointer;
    transition: background .2s ease-in-out;
}

input[type=file]::file-selector-button:hover {
    background: #0d45a5;
}

.drop-container {
    position: relative;
    display: flex;
    margin: 10px;
    gap: 10px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: inherit;
    padding: 5px;
    border-radius: 10px;
    border: 2px dashed #555;
    color: #444;
    cursor: pointer;
    transition: background .2s ease-in-out, border .2s ease-in-out;
}

.drop-container:hover {
    background: #eee;
    border-color: #111;
}

.drop-container:hover .drop-title {
    color: #222;
}

.drop-title {
    color: #444;
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    transition: color .2s ease-in-out;
}

td,
th {
    padding: 5px;
}
</style>

<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
    <?php echo Form::model($produit, ['method' => 'PATCH','route' => ['prodts.update', $produit->id],
    'enctype'=>'multipart/form-data']); ?>


    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                <i class="menu-icon icon-product-hunt   bigger-130"></i> Gestion des produits
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Modification d'un produit
            </div>
        </div>
        <hr class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row">
            <!-- <input type="text" name="poste_id" id="poste_id" hidden> -->
            <input type="text" name="id" id="id" value="<?php echo e($produit->id); ?>" hidden>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9" style="padding:0 25px 0 25px;">
                    <div class="form-group row">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Type produit</strong>
                            <div>
                                <select name="TypeProduitId" id="TypeProduitId">
                                    <option value="">Séléctionner un type produit</option>
                                    <?php $__currentLoopData = $typeproduits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeproduit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($typeproduit->id); ?>"
                                        <?php echo e((old('TypeProduitId',$produit->TypeProduitId)==$typeproduit->id) ? 'selected' : ''); ?>>
                                        <?php echo e($typeproduit->Nom); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('TypeProduitId')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('TypeProduitId')); ?></span>
                            <?php endif; ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Code</strong>
                            <input class="form-control" name="Code"
                                value="<?php echo e(old('Code', isset($produit) ? $produit->Code : '')); ?>" type="text">
                            <?php if($errors->has('Code')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Code')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Libellé</strong>
                            <input class="form-control" name="Libelle"
                                value="<?php echo e(old('Libelle', isset($produit) ? $produit->Libelle : '')); ?>" type="text">
                            <?php if($errors->has('Libelle')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Libelle')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">

                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Famille</strong>
                            <div>
                                <select name="CategProduitId" id="CategProduitId">
                                    <option value="">Séléctionner une famille</option>
                                    <?php $__currentLoopData = $categproduits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categproduit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categproduit->id); ?>"
                                        <?php echo e((old('CategProduitId',$produit->CategProduitId)==$categproduit->id) ? 'selected' : ''); ?>>
                                        <?php echo e($categproduit->Nom); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('CategProduitId')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CategProduitId')); ?></span>
                            <?php endif; ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Unité de gestion</strong>
                            <div>
                                <select name="UniteId" id="UniteId">
                                    <option value="">Séléctionner une unité</option>
                                    <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unite->id); ?>"
                                        <?php echo e((old('UniteId',$produit->UniteId)==$unite->id) ? 'selected' : ''); ?>>
                                        <?php echo e($unite->Nom); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('UniteId')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('UniteId')); ?></span>
                            <?php endif; ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Code barre</strong>
                            <input class="form-control" name="CodeBar"
                                value="<?php echo e(old('CodeBar', isset($produit) ? $produit->CodeBar : '')); ?>" type="text">
                            <?php if($errors->has('CodeBar')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CodeBar')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>CUMP</strong>
                            <input class="form-control  text-right" min='0' name="CUMP"
                                value="<?php echo e(old('CUMP', isset($produit) ? $produit->CUMP : '')); ?>" type="number">
                            <?php if($errors->has('CUMP')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CUMP')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong>Stock sécurité</strong>
                            <input class="form-control text-right" min='0' name="StockSecu"
                                value="<?php echo e(old('StockSecu', isset($produit) ? $produit->StockSecu : '')); ?>"
                                type="number">
                            <?php if($errors->has('StockSecu')): ?>
                            <span class="red" style="font-weight:bold;"><?php echo e($errors->first('StockSecu')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                            <strong></strong>
                            <label style="margin-top:25px;"><input name="Status" type="checkbox" value="on" <?php if((!old()
                                    && $produit->Status) || old('Status') == 'on'): ?> checked="checked" <?php endif; ?>>

                                Actif</label>
                        </div>
                    </div>
                 
                </div>

                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3" style="padding:0 25px 0 25px;">
                    <strong>Logo produit</strong>
                    <div class="form-group row text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">

                        <label for="images" class="drop-container">
                            <input type="file" class="form-control form-control-sm" accept="image/*"
                                style="height: 50px;" id="imgInp" value="<?php echo e(old('Prod_logo')); ?>" name="Prod_logo"
                                onchange="preview()">

                            <img id="blah" src="<?php echo e(asset('storage/images/'.$produit->Prod_logo)); ?>" alt="User photo"
                                width="100px" height="100px" style="border-radius:100px;" />
                        </label>
                        <?php if($errors->has('Prod_logo')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Prod_logo')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

               
            </div>


        </div>
    </div>

    <div class="EnteteContent">
                        <div class="form-group row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <p style="font-size:120%;color:#3f6ad8;font-weight:bold;"><span
                                        class="icon-cart4 bigger-150"></span> Conditionnement vente et achat</p>
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="padding:5px;">
                                    <!-- <span class="col-xs-12 col-sm-12 col-md-4 col-lg-4">Séléctionnez les unités:</span> -->
                                    <!-- <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"> -->
                                    <select name="SelectUniteId" id="SelectUniteId">
                                        <option value="">Aucune séléction</option>
                                        <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unite->id); ?>"
                                            <?php echo e((old('SelectUniteId')==$unite->id) ? 'selected' : ''); ?>>
                                            <?php echo e($unite->Nom); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <!-- </div> -->
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"
                                    style="overflow-y:scroll;max-height:200px;">
                                    <table class="table table-bordered">
                                        <tr style="background:#006fcf;color:#FFF;font-weight:bold;">
                                            <td>Unité</td>
                                            <td hidden>Unité</td>
                                            <td class="text-right">Quantité</td>
                                            <td class="text-right">Prix Achat HT</td>
                                            <td class="text-right">Prix vente HT</td>
                                            <td>Action</td>
                                        </tr>
                                        <tbody id="DetailsUnites">
                                            <?php if($produit->unites->count()>0): ?>
                                            <?php $__currentLoopData = $produit->unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="Unite<?php echo e($unite_product->id); ?>">
                                                <td><?php echo e($unite_product->Nom); ?></td>
                                                <td hidden>
                                                    <input type="number" name="Unite[]" class="form-control text-right"
                                                        value="<?php echo e(old('Unite[]',$unite_product->id)); ?>" />
                                                </td>
                                                <td>
                                                    <input type="text" name="Qte[]" class="form-control text-right"
                                                        value="<?php echo e(old('Qte[]',$unite_product->pivot->Coef)); ?>"
                                                        required />
                                                </td>

                                                <td>
                                                    <input type="number" name="PrixAchat[]"
                                                        class="form-control text-right"
                                                        value="<?php echo e(old('PrixAchat[]',$unite_product->pivot->PrixAchat)); ?>"
                                                        required />
                                                </td>

                                                <td>
                                                    <input type="number" name="PrixVente[]"
                                                        class="form-control text-right"
                                                        value="<?php echo e(old('PrixVente[]',$unite_product->pivot->PrixVente)); ?>"
                                                        required />
                                                </td>
                                                <?php if(count($unite_product->detailachats)==0 && count($unite_product->detailventes)==0 && count($unite_product->regulstocks)==0): ?>
                                                <td style='text-align:center;'><button
                                                        class='btn btn-danger btn-sm remove_this'
                                                        style='width:25px;height:25px;border-radius:100px;'
                                                        type='button' name='Unite<?php echo e($unite_product->id); ?>'><span
                                                            class='fa fa-trash'></span></button></td>
                                                            <?php endif; ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>

    <div class="form-group" style="float:right;margin:15px;">
        <a href="<?php echo e(url('/config/prodts')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i
                    class="glyphicon glyphicon-list"></i> Liste des produits</span></a>

        <button type="submit" value="Create" class="btn btn-warning btn-sm bolder">
            <i class="glyphicon glyphicon-edit"></i> Modifier
        </button>
    </div>
    <?php echo Form::close(); ?>


</div>

<script type="text/javascript">
$(document).ready(function() {

    imgInp.onchange = evt => {
        const [file] = imgInp.files
        if (file) {
            blah.src = URL.createObjectURL(file)
        }
    }

    $(document).on('click', '.remove_this', function() {
        var DivName = $(this).attr("name");
        $("." + DivName).remove();
        return false;
    });



    $('#TypeProduitId').chosen();
    $("#TypeProduitId_chosen").css("width", "100%");

    $('#CategProduitId').chosen();
    $("#CategProduitId_chosen").css("width", "100%");

    $('#UniteId').chosen();
    $("#UniteId_chosen").css("width", "100%");

    $('#SelectUniteId').chosen();
    $("#SelectUniteId_chosen").css("width", "100%");




    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#SelectUniteId').on('change', function(e) {
        var cat_id = e.target.value;
        if ($('.Unite' + cat_id).length < 1 && cat_id != "") {
            $("#DetailsUnites").append("<tr  class='Unite" + cat_id + "'>\
                      <td>" + $('#SelectUniteId option:selected').text() + "</td>\
                      <td hidden><input class='text-right' name='Unite[]' value='" + cat_id + "'  type='number'></td>\
                      <td><input class='form-control text-right' name='Qte[]' min='0'  type='text'  /></td>\
                     <td><input class='form-control text-right' name='PrixAchat[]'   min='0' type='number' required /></td>\
                      <td><input class='form-control text-right' name='PrixVente[]'  min='0' type='number' required /></td>\
                      <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this'\
                      style='width:25px;height:25px;border-radius:100px;' type='button' name='Unite" + cat_id + "'><span class='fa fa-trash'></span></button></td>\
                      </tr>");
        }


    });


    $('#UniteId').on('change', function(e) {
        $("#DetailsUnites").empty();
    });


});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/prodts/edit.blade.php ENDPATH**/ ?>