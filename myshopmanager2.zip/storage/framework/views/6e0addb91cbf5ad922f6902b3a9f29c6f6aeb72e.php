
<link  href="assets/css/chosen.min.css" rel="stylesheet" />
    <script src="assets/js/chosen.jquery.min.js"></script>
                <div style="margin:15px;font-size:15px;">

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Nom: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Nom); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Prénoms: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Prenoms); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Sexe: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Sexe); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Email: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Email); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Téléphone: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Telephone); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Adresse: </label>
                  <div class="col-sm-9">
                  <?php echo e($employe->Adresse); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Date Création: </label>
                  <div class="col-sm-9">
                  <?php echo e(\Carbon\Carbon::parse($employe->DateCreation)->format('d/m/Y')); ?>

                  </div>
                </div>
</div>  <?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/employes/show.blade.php ENDPATH**/ ?>