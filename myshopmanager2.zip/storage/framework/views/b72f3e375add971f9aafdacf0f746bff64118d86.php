
<?php $__env->startSection('content'); ?>
<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">

    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                <i class="icon-android-contacts bigger-130"></i> Gestion des employés
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Aperçu d'un employé
            </div>
        </div>
        <hr  class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row ">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 showStyle">

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code: </strong> <?php echo e($employe->Code); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Nom:</strong> <?php echo e($employe->Nom); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Sexe:</strong> <?php echo e($employe->Sexe); ?>

                    </div>

                </div>

                <div class="form-group row">

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Adresse Electronique:</strong> <?php echo e($employe->Email); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Adresse:</strong> <?php echo e($employe->Adresse); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Poste:</strong> <?php echo e($employe->poste->Libelle); ?>

                    </div>
                </div>

                <div class="form-group row">

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Téléphone:</strong> <?php echo e($employe->Telephone); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Date Naissance:</strong> <?php echo e(\Carbon\Carbon::parse($employe->DateNaissance)->format('d/m/Y')); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Fax:</strong> <?php echo e($employe->Fax); ?>

                    </div>

                </div>

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Pays:</strong> <?php echo e($employe->Pays); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Ville:</strong> <?php echo e($employe->Ville); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code Postal:</strong> <?php echo e($employe->CodePostal); ?>

                    </div>

                </div>

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Status:</strong>  <?php if($employe->Status == 1): ?>
											<span class="badge badge-success">Actif</span>
											<?php else: ?>
											<span class="badge badge-danger">Inactif</span>
											<?php endif; ?>
                    </div>

                </div>

               
            </div>
        </div>
        </div>
        <div class="form-group " style="float:right;">
                    <a href="<?php echo e(url('/config/employes')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i
                                class="glyphicon glyphicon-list"></i> Liste des employés</span></a>
                </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/employes/show.blade.php ENDPATH**/ ?>