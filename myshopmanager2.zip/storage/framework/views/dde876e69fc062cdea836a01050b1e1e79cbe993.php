
<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type=file]::file-selector-button {
        margin-right: 5px;
        border: none;
        background: #084cdf;
        padding: 10px 5px;
        border-radius: 10px;
        color: #fff;
        cursor: pointer;
        transition: background .2s ease-in-out;
    }

    input[type=file]::file-selector-button:hover {
        background: #0d45a5;
    }

    .drop-container {
        position: relative;
        display: flex;
        margin: 10px;
        gap: 10px;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: inherit;
        padding: 5px;
        border-radius: 10px;
        border: 2px dashed #555;
        color: #444;
        cursor: pointer;
        transition: background .2s ease-in-out, border .2s ease-in-out;
    }

    .drop-container:hover {
        background: #eee;
        border-color: #111;
    }

    .drop-container:hover .drop-title {
        color: #222;
    }

    .drop-title {
        color: #444;
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        transition: color .2s ease-in-out;
    }

    td,
    th {
        padding: 5px;
    }

    .innerTd {
        width: 100px;
    }

    .active {
        background-color: aqua;
    }

    #navMenus {
        list-style: none;
    }

    li {
        cursor: pointer;
        margin-bottom: 5px;
    }

    ul {
        margin-left: 0px;
    }

    .tableRecap td {
        white-space: nowrap;
        border-top: 0px solid #ddd;
    }

    .tableRecap td:first-child {
        width: 100%;
        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    .tableRecap td:last-child {
        border-top: 0px solid #ddd;
        padding-top: 1px;
        padding-bottom: 1px;
    }

    input[readonly] {
        color: #939192;
        cursor: default;
    }
</style>

<?php echo Form::open(array('route' => 'vpaiements.store','method'=>'POST')); ?>


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">

        <div class="EnteteContent">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="form-group row ">
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Date commande: </strong> <?php echo e(\Carbon\Carbon::parse($vfact->livraison->commande->DateVente)->format('d/m/Y')); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Réference commande: </strong> <?php echo e($vfact->livraison->commande->Reference); ?>

                        </div>
                    </div>

                    <div class="form-group row ">
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Montant commande: </strong> <?php echo e(number_format($vfact->livraison->commande->MontantTTC,0,',',' ')); ?> <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Date réception: </strong> <?php echo e(\Carbon\Carbon::parse($vfact->livraison->DateLivraison)->format('d/m/Y')); ?>

                        </div>
                    </div>


                    <div class="form-group row ">

                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Réference réception: </strong> <?php echo e($vfact->livraison->Reference); ?>

                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            <strong>Montant réception: </strong> <?php echo e(number_format($vfact->livraison->MontantLivre,0,',',' ')); ?> <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="EnteteContent">
            <div class="row">
                <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                    <i class=" icon-money"></i> Gestion paiements
                </div>

                <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                    Création d'un paiement
                </div>
            </div>
            <hr class="hrEntete">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Référence facture</strong>
                    <input class="form-control" readonly name="ReferenceFacture" value="<?php echo e(old('ReferenceFacture',$vfact->Reference)); ?>" type="text">
                    <input class="form-control hidden" name="FactureId" value="<?php echo e(old('FactureId',$vfact->id)); ?>" type="text">
                </div>
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Mode paiement</strong>
                    <div>
                        <select name="ModePaiementId" id="ModePaiementId">
                            <option value="">Séléctionner un mode paiement</option>
                            <?php $__currentLoopData = $modepaiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modepaiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($modepaiement->id); ?>" <?php echo e((old('ModePaiementId')==$modepaiement->id) ? 'selected' : ''); ?>>
                                <?php echo e($modepaiement->Nom); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if($errors->has('ModePaiementId')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('ModePaiementId')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Compte</strong>
                    <div>
                        <select name="CompteId" id="CompteId">
                            <option value="">Séléctionner un compte</option>
                            <?php $__currentLoopData = $comptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($compte->id); ?>" <?php echo e((old('CompteId')==$compte->id) ? 'selected' : ''); ?>>
                                <?php echo e($compte->Libelle); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if($errors->has('CompteId')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CompteId')); ?></span>
                    <?php endif; ?>
                </div>


            </div>

            <?php if(Auth()->user()->entreprise->AvoirFrManager): ?>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Référence</strong>
                    <input class="form-control" name="Reference" value="<?php echo e(old('Reference',generatePaiementVente())); ?>" type="text">
                    <?php if($errors->has('Reference')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Reference')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Date paiement</strong>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-calendar bigger-110"></i>
                        </span>
                        <input class="form-control datepicker" name="DatePaiement" value="<?php echo e(old('DatePaiement')); ?>" type="text" required>
                    </div>
                    <?php if($errors->has('DatePaiement')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DatePaiement')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <label style="margin-top:25px;"><input name="IsAvoir" type="checkbox">
                        <strong> Mettre la monnaie en avoir</strong></label>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 bolder">
                    <input class="form-control hidden montantavoir" name="MontantAvoir" id="MontantAvoir" value="<?php echo e(old('MontantAvoir',$montantavoir)); ?>" type="text">
                    <label style="margin-top:15px;"> <input name="PaidWithAvoir" id="PaidWithAvoir" type="checkbox">
                        <strong> Payer avec avoir (<span class="avoir"><?php echo e(number_format($montantavoir,0,',',' ')); ?></span>)</strong></label>
                </div>


                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Montant Rémis</strong>
                    <input class="form-control text-right" min='0' id="MontantRemis" name="MontantRemis" value="<?php echo e(old('MontantRemis',$vfact->MontantFacture-$vfact->MontantPaye)); ?>" type="text">
                    <input class="form-control text-right hidden" min='0' id="TotalAPayer" name="TotalAPayer" value="<?php echo e(old('TotalAPayer',$vfact->MontantFacture-$vfact->MontantPaye)); ?>" type="text">

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Remise</strong>
                    <input class="form-control text-right remiseglobale" min='0' id="RemiseGlobale" name="RemiseGlobale" value="<?php echo e(old('RemiseGlobale',0)); ?>" type="text">
                </div>

            </div>

            <div class="row">

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Reste à payer</strong>
                    <input class="form-control text-right" min='0' id="ResteAPayer" name="ResteAPayer" style="background-color:#cad7fa;" value="<?php echo e(old('ResteAPayer',0)); ?>" readonly="readonly" type="text">
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Monnaie</strong>
                    <input class="form-control text-right" min='0' id="Monnaie" name="Monnaie" value="<?php echo e(old('Monnaie',0)); ?>" readonly="readonly" type="text">
                </div>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Référence</strong>
                    <input class="form-control" name="Reference" value="<?php echo e(old('Reference',generatePaiementVente())); ?>" type="text">
                    <?php if($errors->has('Reference')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Reference')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Date paiement</strong>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-calendar bigger-110"></i>
                        </span>
                        <input class="form-control datepicker" name="DatePaiement" value="<?php echo e(old('DatePaiement')); ?>" type="text" required>
                    </div>
                    <?php if($errors->has('DatePaiement')): ?>
                    <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DatePaiement')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Montant Rémis</strong>
                    <input class="form-control text-right" min='0' id="MontantRemis" name="MontantRemis" value="<?php echo e(old('MontantRemis',$vfact->MontantFacture-$vfact->MontantPaye)); ?>" type="text">
                    <input class="form-control text-right hidden" min='0' id="TotalAPayer" name="TotalAPayer" value="<?php echo e(old('TotalAPayer',$vfact->MontantFacture-$vfact->MontantPaye)); ?>" type="text">

                </div>

            </div>

            <div class="row">

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Remise</strong>
                    <input class="form-control text-right remiseglobale" min='0' id="RemiseGlobale" name="RemiseGlobale" value="<?php echo e(old('RemiseGlobale',0)); ?>" type="text">
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Reste à payer</strong>
                    <input class="form-control text-right" min='0' id="ResteAPayer" name="ResteAPayer" style="background-color:#cad7fa;" value="<?php echo e(old('ResteAPayer',0)); ?>" readonly="readonly" type="text">
                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Monnaie</strong>
                    <input class="form-control text-right" min='0' id="Monnaie" name="Monnaie" value="<?php echo e(old('Monnaie',0)); ?>" readonly="readonly" type="text">
                </div>

            </div>
            <?php endif; ?>
        </div>


    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
        <div class="EnteteContent">
            <div class="row">
                <div class="col-sm-12 col-xs-12 col-md-12 col-lg-12">
                    Détails de la facture
                </div>
            </div>
            <hr class="hrEntete">
            <div class=" detailsfact">
                <?php if($vfact !=''): ?>
                <table>

                    <tr>
                        <td>
                            <strong>Fournisseur:</strong> <?php echo e($vfact->livraison->commande->client->Nom); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Date facture:</strong>
                            <?php echo e(\Carbon\Carbon::parse($vfact->DateFacture)->format('d/m/Y')); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Date échéance:</strong>
                            <?php echo e(\Carbon\Carbon::parse($vfact->DateEcheance)->format('d/m/Y')); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Montant facture:</strong> <?php echo e(number_format($vfact->MontantFacture,0,',',' ')); ?>

                            <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Montant payé:</strong> <?php echo e(number_format($vfact->MontantPaye,0,',',' ')); ?>

                            <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </td>
                    </tr>

                    <tr style="background-color:#cad7fa;">
                        <td>
                            <strong>Reste à payer:</strong> <?php echo e(number_format($vfact->MontantFacture-$vfact->MontantPaye,0,',',' ')); ?>

                            <?php echo e(auth()->user()->entreprise->Devise); ?>

                        </td>
                    </tr>


                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>







<div class="form-group" style="float:right;margin:15px;">
    <a href="<?php echo e(route('vpaiements.facture',$vfact->id)); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des paiements</span></a>

    <button type="submit" value="Create" class="btn btn-primary btn-sm bolder">
        <i class="glyphicon glyphicon-plus"></i> Créer
    </button>
</div>
<?php echo Form::close(); ?>



<script type="text/javascript">
    $(document).ready(function() {

        localStorage.setItem("myclass", 'vpaiement');
        localStorage.setItem("father", 'recouv');

        function toNumberFormat(value) {
            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        }


        $('#ModePaiementId').chosen();
        $("#ModePaiementId_chosen").css("width", "100%");

        $('#CompteId').chosen();
        $("#CompteId_chosen").css("width", "100%");

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        function CalculeSumChamps() {
            var remiseglobale = $("#RemiseGlobale").val();
            var montantremis = $("#MontantRemis").val();
            var totalapayer = $("#TotalAPayer").val();

            if ($('#PaidWithAvoir').prop("checked") == true) {
                var montantavoir = $("#MontantAvoir").val();
                var montantpayer = parseFloat(montantremis) + parseFloat(montantavoir) + parseFloat(remiseglobale);
                if (montantpayer >= parseFloat(totalapayer)) {
                    $("#Monnaie").val(parseFloat(montantpayer) - parseFloat(totalapayer));
                    $("#ResteAPayer").val(0);
                } else {
                    $("#Monnaie").val(0);
                    $("#ResteAPayer").val(toNumberFormat(parseFloat(totalapayer) - parseFloat(montantpayer)));
                }

            } else {
                var montantpayer = parseFloat(montantremis) + parseFloat(remiseglobale);;
                if (montantpayer >= parseFloat(totalapayer)) {
                    $("#Monnaie").val(parseFloat(montantpayer) - parseFloat(totalapayer));
                    $("#ResteAPayer").val(0);
                } else {
                    $("#Monnaie").val(0)
                    $("#ResteAPayer").val(toNumberFormat(parseFloat(totalapayer) - parseFloat(montantpayer)));
                }
            }

        }

        $('#MontantRemis').on('change', function(e) {
            if ($(this).val() == "") {
                $(this).val(0);
            }
            CalculeSumChamps();
        });


        $('#RemiseGlobale').on('change', function(e) {
            if ($(this).val() == "") {
                $(this).val(0);
            }
            CalculeSumChamps();
        });

        $('#PaidWithAvoir').on('change', function(e) {
            CalculeSumChamps();
        });
        
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/recouv/vpaiements/create.blade.php ENDPATH**/ ?>