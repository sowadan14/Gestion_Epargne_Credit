
<?php $__env->startSection('content'); ?>
<div class="EnteteContent">
    <div class="row">

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
            <i class="menu-icon icon-group bigger-130"></i> Gestion des entreprises
        </div>

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
            Aperçu d'une entreprise
        </div>
    </div>
    <hr class="hrEntete">
    <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

    <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
    <div class="row ">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 showStyle">

            <div class="form-group row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Code: </strong> <?php echo e($entreprise->Code); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Nom:</strong> <?php echo e($entreprise->Nom); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Nom réduit:</strong> <?php echo e($entreprise->NomReduit); ?>

                </div>



            </div>

            <div class="form-group row">

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Adresse Electronique:</strong> <?php echo e($entreprise->Email); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Adresse:</strong> <?php echo e($entreprise->Adresse); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Téléphone:</strong> <?php echo e($entreprise->Telephone); ?>

                </div>



            </div>

            <div class="form-group row">

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Fax:</strong> <?php echo e($entreprise->Fax); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Pays:</strong> <?php echo e($entreprise->Pays); ?>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Ville:</strong> <?php echo e($entreprise->Ville); ?>

                </div>
               
            </div>
            <div class="form-group row">

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Code Postal:</strong> <?php echo e($entreprise->CodePostal); ?>

                </div>

            </div>



            <div class="form-group " style="float:right;">
                <a href="<?php echo e(url('/entreprises')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des entreprises</span></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/entreprises/show.blade.php ENDPATH**/ ?>