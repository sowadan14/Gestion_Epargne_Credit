

<?php if($produit!=''): ?>
<tr class='PUnite<?php echo e($produit->UniteId); ?><?php echo e($produit->id); ?>'>
    <td><?php echo e($produit->Libelle); ?></td>
    <td><?php echo e($produit->unite->Nom); ?></td>

    <td>
        <select name="FromUniteId[]" id="FromUniteId" class="SelectedUnite2">
            <option value="">Séléctionner une unité</option>
            <?php $__currentLoopData = $produit->unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($unite->pivot->Qte>0): ?>
            <option value="<?php echo e($unite->id); ?>" <?php echo e((old('FromUniteId')==$unite->id) ?
                                    'selected' : ''); ?>>
                <?php echo e($unite->Nom); ?>(<?php echo e(number_format($unite->pivot->Qte,0,',',' ')); ?>)
            </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>

    <td>
    <select name="ToUniteId[]" id="ToUniteId"  class="SelectedUnite1">
            <option value="">Séléctionner une unité</option>
            <?php $__currentLoopData = $produit->unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unite->id); ?>" <?php echo e((old('ToUniteId')==$unite->id) ?
                                    'selected' : ''); ?>>
                <?php echo e($unite->Nom); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>

    <td hidden><input class='text-right form-control' name='Produit[]' value='<?php echo e($produit->id); ?>' type='number'></td>
    <td hidden><input class='text-right form-control' name='Unite[]' value='<?php echo e($produit->UniteId); ?>' type='number'></td>
    <td><input class='text-right form-control' list='PUnite<?php echo e($produit->UniteId); ?><?php echo e($produit->id); ?>' name='Qte[]' min='0' value="0" type='number' required /></td>
      <td style='text-align:center;'><button class='btn btn-danger btn-sm remove_this' style='width:25px;height:25px;border-radius:100px;' type='button' name='PUnite<?php echo e($produit->UniteId); ?><?php echo e($produit->id); ?>'><span class='fa fa-trash'></span></button></td>
</tr>
<?php endif; ?>


<script type="text/javascript">
    $(document).ready(function () {
       
        $('.SelectedUnite1').chosen();
        $(".SelectedUnite1_chosen").css("width", "100%");

        
        $('.SelectedUnite2').chosen();
        $(".SelectedUnite2_chosen").css("width", "100%");


    });
</script><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/stock/convertstocks/tablestock.blade.php ENDPATH**/ ?>