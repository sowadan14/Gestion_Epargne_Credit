
<?php $__env->startSection('content'); ?>
<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
    <?php echo Form::model($employe, ['method' => 'PATCH','route' => ['employes.update', $employe->id]]); ?>


    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
                <i class="icon-android-contacts bigger-130"></i> Gestion des employés
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Modification d'un employé
            </div>
        </div>
        <hr class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row">
            <input type="text" name="id" id="id" value="<?php echo e($employe->id); ?>" hidden>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:0 25px 0 25px;">

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code</strong>
                        <input class="form-control" name="Code" value="<?php echo e(old('Code',$employe->Code)); ?>" type="text">
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Nom</strong>
                        <input class="form-control" name="Nom" type="text" value="<?php echo e(old('Nom',$employe->Nom)); ?>" required>
                        <?php if($errors->has('Nom')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Nom')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Sexe</strong>
                        <div>
                            <select name="Sexe" id="Sexe">
                                <option value="">Séléctionner un sexe</option>
                                <?php $__currentLoopData = $sexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sexe->value); ?>" <?php echo e((old('Sexe',$employe->Sexe)==$sexe->value) ? 'selected' : ''); ?>><?php echo e($sexe->text); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('Sexe')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Sexe')); ?></span>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="form-group row">

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Adresse Electronique <?php echo e(old('Email')); ?></strong>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="fa fa-envelope-o bigger-110"></i>
                            </span>
                            <input class="form-control" name="Email" type="text" value="<?php echo e(old('Email',$employe->Email)); ?>" required>
                        </div>
                        <?php if($errors->has('Email')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Email')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Adresse</strong>
                        <input class="form-control" name="Adresse" value="<?php echo e(old('Adresse',$employe->Adresse)); ?>" type="text">
                        <?php if($errors->has('Adresse')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Adresse')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Poste</strong>
                        <div>
                            <select name="PosteId" id="PosteId">
                                <option value="">Séléctionner un poste</option>
                                <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($poste->id); ?>" <?php echo e((old('PosteId',$employe->PosteId)==$poste->id) ? 'selected' : ''); ?>><?php echo e($poste->Libelle); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('PosteId')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('PosteId')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Téléphone</strong>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="ace-icon fa fa-phone"></i>
                            </span>
                            <input class="form-control" name="Telephone" value="<?php echo e(old('Telephone',$employe->Telephone)); ?>" type="text" required>
                        </div>
                        <?php if($errors->has('Telephone')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Telephone')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Date Naissance</strong>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="fa fa-calendar bigger-110"></i>
                            </span>
                            <input class="form-control datepicker" name="DateNaissance" value="<?php echo e(old('DateNaissance',\Carbon\Carbon::parse($employe->DateNaissance)->format('d/m/Y'))); ?>" type="text" required>
                        </div>
                        <?php if($errors->has('DateNaissance')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('DateNaissance')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Fax</strong>
                        <input class="form-control" name="Fax" value="<?php echo e(old('Fax',$employe->Fax)); ?>" type="text">
                        <?php if($errors->has('Fax')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Fax')); ?></span>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Pays</strong>
                        <input class="form-control" name="Pays" value="<?php echo e(old('Pays',$employe->Pays)); ?>" type="text">
                        <?php if($errors->has('Pays')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Pays')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Ville</strong>
                        <input class="form-control" name="Ville" value="<?php echo e(old('Ville',$employe->Ville)); ?>" type="text">
                        <?php if($errors->has('Ville')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('Ville')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code Postal</strong>
                        <input class="form-control" name="CodePostal" value="<?php echo e(old('CodePostal',$employe->CodePostal)); ?>" type="text">
                        <?php if($errors->has('CodePostal')): ?>
                        <span class="red" style="font-weight:bold;"><?php echo e($errors->first('CodePostal')); ?></span>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="form-group row">


                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

                        <label><input name="Status" type="checkbox" value="on" <?php if((!old() && $employe->Status) || old('Status') == 'on'): ?> checked="checked" <?php endif; ?>>
                            <strong> Actif</strong></label>
                    </div>

                </div>

                
            </div>
        </div>
    </div>
    <div class="form-group " style="float:right;">
                    <a href="<?php echo e(url('/config/employes')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i class="glyphicon glyphicon-list"></i> Liste des employés</span></a>

                    <button type="submit" value="Create" class="btn btn-warning btn-sm bolder">
                        <i class="glyphicon glyphicon-edit"></i> Modifier
                    </button>
                </div>
            <?php echo Form::close(); ?>


</div>
<script>
    $(document).ready(function() {

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })

        $('#PosteId').chosen();
        $("#PosteId_chosen").css("width", "100%");

        $('#Sexe').chosen();
        $("#Sexe_chosen").css("width", "100%");

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/employes/edit.blade.php ENDPATH**/ ?>