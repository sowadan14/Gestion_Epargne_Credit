
<link  href="assets/css/chosen.min.css" rel="stylesheet" />
    <script src="assets/js/chosen.jquery.min.js"></script>
                <div style="margin:15px;font-size:15px;">

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Libellé: </label>
                  <div class="col-sm-9">
                  <?php echo e($compte->Libelle); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> SoldeInitial: </label>
                  <div class="col-sm-9">
                  <?php echo e($compte->SoldeInitial); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Solde: </label>
                  <div class="col-sm-9">
                  <?php echo e($compte->Solde); ?>

                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 control-label no-padding-right" style="font-weight:bold;"> Date Création: </label>
                  <div class="col-sm-9">
                  <?php echo e(\Carbon\Carbon::parse($compte->DateCreation)->format('d/m/Y')); ?>

                  </div>
                </div>
</div> <?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/comptes/show.blade.php ENDPATH**/ ?>