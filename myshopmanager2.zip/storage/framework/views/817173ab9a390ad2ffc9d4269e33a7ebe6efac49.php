
<link  href="assets/css/chosen.min.css" rel="stylesheet" />
    <script src="assets/js/chosen.jquery.min.js"></script>

<form id="compteForm" name="compteForm" method="post" class="form-horizontal">
                <input type="hidden" name="id" id="id"   value="<?php echo e($compte->id); ?>">
                <div style="overflow-y:auto;max-height:450px;margin:15px;">
            <div class="alert alert-danger" style="display:none"></div>


<div class="col-lg-12 col-md-12 col-sm-12">
           <div style="margin-bottom:10px;margin-top:28px;">
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="font-weight:bold;font-size:15px;">
                <strong>Libellé:</strong>
                <input class="form-control" name="libelle" type="text"   value="<?php echo e($compte->Libelle); ?>">
        </div>
</div>


           </div>
</div>
</form><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/comptes/edit.blade.php ENDPATH**/ ?>