
<?php $__env->startSection('content'); ?>
<div class="EnteteContent">
    <div class="row">

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
            <i class=" menu-icon icon-android-compass  bigger-130"></i> Régularisation stock
        </div>

        <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">

            <div class="btn-group dropleft" style="float: right;">
                <button data-toggle="dropdown" class="btn btn-primary btn-white btn-xs dropdown-toggle blue" aria-expanded="false">
                    <span class="blue" style="font-weight:bold;">
                        <i class="glyphicon glyphicon-align-justify"></i> Option
                        <span class="ace-icon fa fa-caret-down icon-on-right"></span>
                    </span>

                </button>


                <ul class="dropleft dropdown-menu dropdown-inverse">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createalist')): ?>
                    <li>
                        <a href="<?php echo e(route('regulstocks.create')); ?>" style="vertical-align: inherit;"><span class="glyphicon glyphicon-plus blue"></span> Nouvelle régularisation stock</a>
                    </li>
                    <?php endif; ?>

                    <li>
                        <a href="#" id="dd"><span class="icon-file-excel-o green"></span> Exporter la séléction en
                            excel</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <hr class="hrEntete">
    <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('danger')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>
    <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-stripped data-table">
                            <thead>
                                <tr>
                                    <th hidden>N°</th>
                                    <th class="text-center">
                                        <?php echo e(Form::checkbox('SelectedAll[]',false,false, array('class' =>
											'checkbox','id' => 'SelectedAll'))); ?>

                                    </th>

                                    <th>Produit</th>
                                    <!-- <th>Unité</th> -->
                                    <th class="text-center">Sens</th>
                                    <th class="text-right">Quantité</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($data) > 0): ?>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($row->Qte > 0): ?>
                                <tr>
                                    <!-- <td><img src="<?php echo e(asset('images/' . $row->student_image)); ?>" width="75" /></td> -->
                                    <td hidden><?php echo e($row->id); ?></td>
                                    <td class="text-center"><?php echo e(Form::checkbox('Selected[]',$row->id, false)); ?></td>
                                    <td><?php echo e($row->produit->Libelle); ?></td>
                                    <!-- <td><?php echo e($row->unite->Nom); ?></td> -->
                                    <td class="text-center"><?php if($row->Entree == 1): ?>
                                        <span class="badge badge-success">Entrée</span>
                                        <?php else: ?>
                                        <span class="badge badge-danger">Sortie</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right">
                                        <?php if($row->Qte == 1): ?>
                                        <?php echo e(number_format($row->Qte,0,',',' ')); ?> <?php echo e($row->unite->Nom); ?>

                                        <?php else: ?>
                                        <?php echo e(number_format($row->Qte,0,',',' ')); ?> <?php echo e($row->unite->Nom); ?>s
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group dropleft" style="float: center;">
                                            <button data-toggle="dropdown" class="btn btn-primary btn-xs dropdown-toggle blue" aria-expanded="false">
                                                <span style="font-weight:bold;">
                                                    Actions
                                                    <span class="ace-icon fa fa-caret-down icon-on-right"></span>
                                                </span>

                                            </button>


                                            <ul class="dropleft dropdown-menu dropdown-inverse">
                                                <li>
                                                    <p style="min-width:250px;margin:0 0 0px;">
                                                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editalist')): ?>

                                                        <a href="<?php echo e(route('regulstocks.edit',$row->id)); ?>" style="padding-bottom:0px;" class="btn btn-warning btn-xs bolder"><span class="glyphicon glyphicon-edit"></span>
                                                            Modifier</a>

                                                        <?php endif; ?>


                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletealist')): ?>

                                                        <!-- <?php echo Form::open(['method' => 'DELETE','route' => ['regulstocks.destroy',
													$row->id],'style'=>'display:inline','id'=>'SubmitForm']); ?> -->

                                                        <a data-id="<?php echo e($row->id); ?>" role="<?php echo e($row->Reference); ?>" class="show_confirm btn btn-danger btn-xs bolder"><span class="ace-icon fa fa-trash-o bigger-120"></span>
                                                            Supprimer</a>

                                                        <!-- <?php echo Form::close(); ?> -->

                                                        <?php endif; ?>


                                                    </p>
                                                </li>
                                            </ul>
                                        </div>

                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div hidden>
    <?php echo Form::open(['method' => 'DELETE','style'=>'display:inline','id'=>'SubmitForm']); ?>


    <?php echo Form::close(); ?>


</div>

<script type="text/javascript">
    localStorage.setItem("myclass", 'regulstock');
    localStorage.setItem("father", 'regul');

    $('.show_confirm').click(function(event) {
        var id = $(this).data('id');
        var name = $(this).attr('role');
        $("#SubmitForm").attr('action', '/regul/regulstocks/' + id);

        event.preventDefault();
        swal({
                title: `Etes-vous sûr de vouloir supprimer cette régularisation stock ` + name + '?',
                text: "Il n'y a plus de retour en arrière.",
                icon: "error",
                buttons: true,
                buttons: ["Annuler", "Supprimer"],
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $("#SubmitForm").submit();
                }
            });
    });
</script>



<script type="text/javascript">
    $(function() {



        /*------------------------------------------
         --------------------------------------------
         Pass Header Token
         --------------------------------------------
         --------------------------------------------*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        /*------------------------------------------
        --------------------------------------------
        Render DataTable
        --------------------------------------------
        --------------------------------------------*/
        var table = $('.data-table').DataTable({
            "language": {
                "thousands": ' ',
                "decimal": ",",
                "thousands": " ",
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            },
            processing: true,
            ordering: false,
            // serverSide: true,
            "order": [
                [0, 'desc']
            ],
        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/regul/regulstocks/index.blade.php ENDPATH**/ ?>