<table>

<tr>
    <td>
        <strong>Date réception:</strong>
        <?php echo e(\Carbon\Carbon::parse($recep->DateReception)->format('d/m/Y')); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Date commande:</strong>
        <?php echo e(\Carbon\Carbon::parse($recep->commande->DateAchat)->format('d/m/Y')); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Montant réception:</strong> <?php echo e(number_format($recep->MontantReçu,0,',',' ')); ?>

        <?php echo e(auth()->user()->entreprise->Devise); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Fournisseur:</strong> <?php echo e($recep->commande->fournisseur->Nom); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Status réception:</strong>
        <?php
        $StatusReception=round(($recep->commande->MontantReçu/$recep->commande->MontantTTC)*100);
        ?>
        <div class="progress pos-rel" data-percent="<?php echo e($StatusReception); ?>%">
            <div class="progress-bar" style="width:<?php echo e($StatusReception); ?>%;"></div>
        </div>
    </td>
</tr>
</table><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/achat/afacts/detailCmde.blade.php ENDPATH**/ ?>