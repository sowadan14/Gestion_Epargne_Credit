

<?php $__env->startSection('content'); ?>
<div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
              <li>
                <i class="ace-icon glyphicon glyphicon-th-list"></i>
                <a href="#">Tables</a>
              </li>
              <li class="active">Table basique</li>
            </ul><!-- /.breadcrumb -->

            <!-- <div class="nav-search" id="nav-search">
              <form class="form-search">
                <span class="input-icon">
                  <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                  <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
              </form>
            </div>/.nav-search -->
          </div>
          <div class="page-content">
            <div class="page-header">
              <h1>
               Liste des utilisateurs 
                <!-- <small>
                  <i class="ace-icon fa fa-angle-double-right"></i>
                  overview &amp; stats
                </small> -->
              </h1>
            </div><!-- /.page-header -->
<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table  table-striped table-bordered" style="width:100%;">
            <thead>
              <tr>
              <th>N°</th>              
                <th>Email</th>                
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->email); ?></td>
              </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


 
 
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/Users/List.blade.php ENDPATH**/ ?>