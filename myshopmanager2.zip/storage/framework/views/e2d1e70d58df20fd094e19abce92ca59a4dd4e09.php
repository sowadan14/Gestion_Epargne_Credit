<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
                <form id="posteForm" name="posteForm" method="post" class="form-horizontal">
                   <input type="text" name="poste_id" id="poste_id">
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="Libelle"> Libellé </label>
										<div class="col-sm-9">
											<input type="text" id="Libelle" name="Libelle" placeholder=""  class="col-sm-12">
										</div>
									</div>
                  
                </form>
            </div>
            <div class="modal-footer">
            <div class="col-sm-12">
            <button type="button" class="btn  btn-default btn-round float-lg-left Closer btn-md" data-dismiss="modal" style="float:left;"><i class="ace-icon fa fa-times"></i> Fermer</button>
           <button type="submit" id="CreateForm" value="Create" class="btn btn-primary Saver btn-md btn-round" >
           <i class="ace-icon fa fa-floppy-o bigger-120"></i> Enregistrer
            </button>
                    </div>
                   
</div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/Postes/create.blade.php ENDPATH**/ ?>