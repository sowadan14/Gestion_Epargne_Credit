<?php if($livr!=''): ?>
<table>

<tr>
    <td>
        <strong>Date livraison:</strong>
        <?php echo e(\Carbon\Carbon::parse($livr->DateReception)->format('d/m/Y')); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Date commande:</strong>
        <?php echo e(\Carbon\Carbon::parse($livr->commande->DateAchat)->format('d/m/Y')); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Montant livraison:</strong> <?php echo e(number_format($livr->MontantLivre,0,',',' ')); ?>

        <?php echo e(auth()->user()->entreprise->Devise); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Fournisseur:</strong> <?php echo e($livr->commande->client->Nom); ?>

    </td>
</tr>

<tr>
    <td>
        <strong>Status livraison:</strong>
        

        <?php

if(($livr->commande->MontantLivre/$livr->commande->MontantTTC)*100 < 99.9999 && ($livr->commande->MontantLivre/$livr->commande->MontantTTC)*100 > 99.9)
    {
    $StatusReception=99;
    }
    else
    {
    $StatusReception=round(($livr->commande->MontantLivre/$livr->commande->MontantTTC)*100);
    }
    ?>
        <div class="progress pos-rel" data-percent="<?php echo e($StatusReception); ?>%">
            <div class="progress-bar" style="width:<?php echo e($StatusReception); ?>%;"></div>
        </div>
    </td>
</tr>
</table>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/recouv/vfacts/detailCmde.blade.php ENDPATH**/ ?>