
<?php $__env->startSection('content'); ?>
<div class="col-sm-12 col-xs-12 col-md-2 col-lg-2">
    <?php echo $__env->make('layouts.configmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col-sm-12 col-xs-12 col-md-10 col-lg-10">
    <div class="EnteteContent">
        <div class="row">

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 styleEntete">
            <i class="icon-money  bigger-130"></i>	Gestion des unités
            </div>

            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 text-right styleAction">
                Aperçu d'un mode de paiement
            </div>
        </div>
        <hr  class="hrEntete">
        <!-- <p><button class="btn btn-sm btn-primary"><span class=" glyphicon glyphicon-plus"></span> Nouveau</button></p> -->

        <!-- <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct"> Create New Product</a> -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 showStyle">
                <div class="form-group row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <strong>Code: </strong> <?php echo e($modepaiement->Code); ?>

                        <!-- <input class="form-control" name="Code"  value="{{old('Code')}}"  type="text" value="<?php echo e($modepaiement->Code); ?>"> -->
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Libellé: </strong> <?php echo e($modepaiement->Nom); ?>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <strong>Status: </strong> 
                    <?php if($modepaiement->Status == 1): ?>
											<span class="badge badge-success">Actif</span>
											<?php else: ?>
											<span class="badge badge-danger">Inactif</span>
											<?php endif; ?>
                    </div>
                    
                </div>

                <div class="form-group " style="float:right;">
                    <a href="<?php echo e(url('/config/mpaiements')); ?>" class="btn btn-success btn-sm"><span class="dark bolder"><i
                                class="glyphicon glyphicon-list"></i> Liste des modes de paiement</span></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyShopManager\resources\views/config/mpaiements/show.blade.php ENDPATH**/ ?>