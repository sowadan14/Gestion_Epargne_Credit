<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVentesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ventes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('ClientId');    
            $table->unsignedBigInteger('CompteId')->nullable();
            $table->unsignedBigInteger('ModePaiementId')->nullable();     
            $table->string('Reference')->nullable();
            $table->string('RefVente')->nullable();
            $table->boolean('Status')->default('0');
            $table->boolean('StatusLivraison')->default('0');
            $table->boolean('EstDevis')->default('0');
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
            $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->bigInteger('Qte')->default(0);
            $table->integer('QteLivre')->default(0);
            $table->decimal('MontantHT',25,2)->default(0);
            $table->decimal('MontantTTC',25,2)->default(0);
            $table->decimal('Remise',25,2)->default(0);
            $table->decimal('RemiseGlobale',25,2)->default(0);
            $table->decimal('Tva',25,2)->default(0);
            $table->decimal('MontantPaye',25,2)->default(0);
            $table->decimal('MontantLivre',25,2)->default(0);
            $table->datetime('DateVente');    
            $table->datetime('DateLivraison')->nullable();;           
            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade'); 

           
            $table->foreign('ClientId')
                 ->references('id')
                 ->on('clients')->onDelete('cascade'); 

            // $table->unsignedBigInteger('CompteId');
            // $table->foreign('CompteId')
            //      ->references('id')
            //      ->on('comptes')->onDelete('cascade'); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ventes');
    }
}
