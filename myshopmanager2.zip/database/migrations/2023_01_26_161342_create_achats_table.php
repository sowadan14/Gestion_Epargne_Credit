<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAchatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('achats', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('CompteId')->nullable();
            $table->unsignedBigInteger('ModePaiementId')->nullable();
            // $table->unsignedBigInteger('ProduitId');
            $table->unsignedBigInteger('FournisseurId');
            $table->string('Reference')->nullable();
            $table->string('RefAchat')->nullable();
            $table->boolean('Status')->default('0');
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
           $table->bigInteger('Qte')->default(0);
            $table->integer('QteReçu')->default(0);
            $table->decimal('MontantHT',25,2)->default(0);
            $table->decimal('MontantTTC',25,2)->default(0);
            $table->decimal('Remise',25,2)->default(0);
            $table->decimal('RemiseGlobale',25,2)->default(0);
            $table->decimal('Tva',25,2)->default(0);
            $table->decimal('MontantPaye',25,2)->default(0);
            $table->decimal('MontantReçu',25,2)->default(0);
            $table->datetime('DateAchat');    
            $table->datetime('DateReception')->nullable();  
            $table->boolean('StatusReception')->default('0');      
            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');

            // $table->foreign('ProduitId')
            //      ->references('id')
            //      ->on('produits')->onDelete('cascade');

            $table->foreign('FournisseurId')
                 ->references('id')
                 ->on('fournisseurs')->onDelete('cascade');

                //  $table->unsignedBigInteger('CompteId');
                //  $table->foreign('CompteId')
                //       ->references('id')
                //       ->on('comptes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('achats');
    }
}
