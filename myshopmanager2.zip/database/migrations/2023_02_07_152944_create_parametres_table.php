<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateParametresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Schema::create('parametres', function (Blueprint $table) {
        //     $table->bigIncrements('id');
        //     $table->unsignedBigInteger('EntrepriseId');
        //     $table->integer('Taille');
        //     $table->string('Police');
        //     $table->string('ColorEntete')->nullable();
        //     $table->string('ColorSidebar')->nullable();
        //     $table->string('LogoEntreprise')->nullable();
        //     $table->string('EmailNotification')->nullable();
        //     $table->string('PasswordNotification')->nullable();
        //     $table->string('Nom');
        //     $table->string('NomReduit');
        //     $table->string('Email');
        //     $table->string('Adresse')->nullable();
        //     $table->string('Telephone')->nullable();
        //     $table->boolean('Supprimer')->default(0);
        //     $table->datetime('Supp_util')->nullable();
        //      $table->datetime('Modif_util')->nullable();
            // $table->string('Create_user')->nullable();
            // $table->string('Edit_user')->nullable();
            // $table->string('Delete_user')->nullable();
        //     $table->string('Code')->nullable();
        //     $table->datetime('DateCreation'); 
        //     $table->timestamps();
        //     $table->foreign('EntrepriseId')->references('id')->on('entreprises')->onDelete('cascade');
        // });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Schema::dropIfExists('parametres');
    }
}
