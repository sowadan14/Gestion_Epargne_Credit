<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UnitesproduitsTable extends Migration
{
   
   public function up()
   {
       Schema::create('uniteproduits', function (Blueprint $table) {
        // $table->bigIncrements('id');
           $table->unsignedBigInteger('ProduitId');
           $table->unsignedBigInteger('UniteId');
           $table->decimal('PrixVente',25,2)->default(0);
           $table->decimal('PrixAchat',25,2)->default(0);
          $table->bigInteger('Qte')->default(0);
           $table->decimal('Coef',25,2)->default(0);
           $table->boolean('Supprimer')->default(0);
           $table->datetime('Supp_util')->nullable();
            $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
           $table->timestamps();

           $table->foreign('ProduitId')
           ->references('id')
           ->on('produits')->onDelete('cascade');

           $table->foreign('UniteId')
           ->references('id')
           ->on('unites')->onDelete('cascade');
       });
   }

   /**
    * Reverse the migrations.
    *
    * @return void
    */
   public function down()
   {
       Schema::dropIfExists('uniteproduits');
   }

}
