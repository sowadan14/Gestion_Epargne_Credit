<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRegulstockTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('regulstocks', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('ProduitId');
            $table->unsignedBigInteger('UniteId');
            $table->bigInteger('Qte')->default(0);
            $table->bigInteger('Entree')->default(1);
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
             $table->string('Create_user')->nullable();
             $table->string('Edit_user')->nullable();
             $table->string('Delete_user')->nullable();
            $table->timestamps();
 
            $table->foreign('ProduitId')
            ->references('id')
            ->on('produits')->onDelete('cascade');
 
            $table->foreign('UniteId')
            ->references('id')
            ->on('unites')->onDelete('cascade');

            $table->foreign('EntrepriseId')
            ->references('id')
            ->on('entreprises')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('regulstocks');
    }
}
