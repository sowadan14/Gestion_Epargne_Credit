<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDetailscompteTable extends Migration
{
 

    /**
     * Reverse the migrations.
     *
     * @return void
     */
   

    public function up()
    {
        Schema::create('detailscomptes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('CompteId');
            $table->decimal('Credit',25,2)->default(0);
            $table->decimal('Debit',25,2)->default(0);
            // $table->bigInteger('Entree')->default(1);
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Libelle')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->datetime('DateOperation')->nullable();  
            $table->timestamps();

            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');

                 $table->foreign('CompteId')
                      ->references('id')
                      ->on('comptes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detailscomptes');
    }
}
