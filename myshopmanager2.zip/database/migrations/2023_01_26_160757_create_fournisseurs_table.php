<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFournisseursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fournisseurs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->string('Nom');
            $table->string('Pays')->nullable();;
            $table->string('Ville')->nullable();;
            $table->string('CodePostal')->nullable();;
            $table->string('Fax')->nullable();;
            $table->string('Code')->nullable();
            $table->boolean('Status')->default(1);

            $table->string('Email')->nullable();
            $table->string('Adresse')->nullable();
            $table->string('Telephone')->nullable();
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            // $table->datetime('DateNaissance'); 
            // $table->datetime('DateCreation');            
            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fournisseurs');
    }
}
