<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('PosteId');
            $table->string('Nom');
            $table->string('Pays')->nullable();
            $table->string('Ville')->nullable();
            $table->string('CodePostal')->nullable();
            $table->string('Fax')->nullable();
            $table->string('Code')->nullable();
            $table->boolean('Status')->default('0');
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->string('Sexe');
            $table->string('Email');
            $table->string('Adresse')->nullable();
            $table->string('Telephone')->nullable();
            $table->datetime('DateNaissance'); 
            // $table->datetime('DateCreation');            
            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');
            $table->foreign('PosteId')
                 ->references('id')
                 ->on('postes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employes');
    }
}
