<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaiementventeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('paiementventes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('CompteId');
            $table->unsignedBigInteger('ModePaiementId');
            $table->unsignedBigInteger('FactureId');
            $table->string('Reference')->nullable();
            $table->decimal('Montant',25,2)->default(0);
            $table->decimal('Monnaie',25,2)->default(0);
            $table->decimal('MontantRemis',25,2)->default(0);
            $table->decimal('MontantAvoir',25,2)->default(0);
            $table->decimal('Remise',25,2)->default(0);
            $table->boolean('Supprimer')->default(0);
            $table->boolean('PaidWithAvoir')->default(0);
            $table->boolean('IsAvoir')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->datetime('DatePaiement')->nullable();   

            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');

            // $table->foreign('ProduitId')
            //      ->references('id')
            //      ->on('produits')->onDelete('cascade');

            $table->foreign('FactureId')
                 ->references('id')
                 ->on('factureventes')->onDelete('cascade');

                 $table->foreign('ModePaiementId')
                 ->references('id')
                 ->on('modepaiements')->onDelete('cascade');

                
                 $table->foreign('CompteId')
                      ->references('id')
                      ->on('comptes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('paiementventes');
    }
}
