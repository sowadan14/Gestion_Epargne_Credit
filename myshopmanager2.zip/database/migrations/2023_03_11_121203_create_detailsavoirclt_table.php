<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDetailsavoircltTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detailsavoirclts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('AvoirCltId');
            $table->unsignedBigInteger('EntrepriseId');
            $table->bigInteger('Entree')->default(0);
            $table->string('Libelle')->nullable();
            $table->decimal('Montant',25,2)->default(0);
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->datetime('DateAvoir')->nullable();
            $table->timestamps();

            $table->foreign('AvoirCltId')
            ->references('id')
            ->on('avoirclts')->onDelete('cascade');

            $table->foreign('EntrepriseId')
            ->references('id')
            ->on('entreprises')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detailsavoirclts');
    }
}
