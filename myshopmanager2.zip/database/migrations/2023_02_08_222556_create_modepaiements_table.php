<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateModepaiementsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modepaiements', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->string('Nom');
            $table->string('Code')->nullable();
            $table->boolean('Status')->default(1);
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->timestamps();
            
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')
                 ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modepaiements');
    }
}
