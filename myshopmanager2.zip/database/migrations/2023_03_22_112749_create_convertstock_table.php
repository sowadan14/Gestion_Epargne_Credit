<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConvertstockTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('convertstocks', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            $table->unsignedBigInteger('ProduitId');
            $table->unsignedBigInteger('FromUniteId');
            $table->unsignedBigInteger('ToUniteId');
            $table->decimal('FromQte',25,2)->default(0);
            $table->decimal('ToQte',25,2)->default(0);
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
             $table->string('Create_user')->nullable();
             $table->string('Edit_user')->nullable();
             $table->string('Delete_user')->nullable();
            $table->timestamps();
 
            $table->foreign('ProduitId')
            ->references('id')
            ->on('produits')->onDelete('cascade');
 
            $table->foreign('FromUniteId')
            ->references('id')
            ->on('unites')->onDelete('cascade');

            $table->foreign('ToUniteId')
            ->references('id')
            ->on('unites')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('convertstocks');
    }
}
