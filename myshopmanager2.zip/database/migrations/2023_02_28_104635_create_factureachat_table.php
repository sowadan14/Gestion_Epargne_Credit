<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFactureachatTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('factureachats', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('EntrepriseId');
            // $table->unsignedBigInteger('ProduitId');
            $table->unsignedBigInteger('ReceptionId');
            $table->string('Reference')->nullable();
            $table->decimal('MontantFacture',25,2)->default(0);
            $table->decimal('MontantPaye',25,2)->default(0);
            $table->decimal('Remise',25,2)->default(0);
            $table->boolean('Status')->default('0');
            $table->boolean('Supprimer')->default(0);
            $table->datetime('Supp_util')->nullable();
             $table->datetime('Modif_util')->nullable();
            $table->string('Create_user')->nullable();
            $table->string('Edit_user')->nullable();
            $table->string('Delete_user')->nullable();
            $table->datetime('DateFacture')->nullable(); 
            $table->datetime('DateEcheance')->nullable();      
            $table->timestamps();
            $table->foreign('EntrepriseId')
                 ->references('id')
                 ->on('entreprises')->onDelete('cascade');

            // $table->foreign('ProduitId')
            //      ->references('id')
            //      ->on('produits')->onDelete('cascade');

            $table->foreign('ReceptionId')
                 ->references('id')
                 ->on('receptionachats')->onDelete('cascade');

                //  $table->unsignedBigInteger('CompteId');
                //  $table->foreign('CompteId')
                //       ->references('id')
                //       ->on('comptes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('factureachats');
    }
}
