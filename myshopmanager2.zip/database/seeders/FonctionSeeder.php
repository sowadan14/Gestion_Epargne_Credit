<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FonctionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('fonctions')->truncate();
          //Creation fonction
          DB::table('fonctions')->insert([
            'id'=>'1',
            'Name'=>'PDG',
            'EntrepriseCateg'=>'1',
            'SaveNumber'=>'1',
            'AnnexeID'=>'1',
        ]);

        DB::table('fonctions')->insert([
            'id'=>'2',
            'Name'=>'Comptable',
            'EntrepriseCateg'=>'1',
            'SaveNumber'=>'2',
            'AnnexeID'=>'1',
        ]);
    }
}
