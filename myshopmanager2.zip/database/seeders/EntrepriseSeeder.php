<?php

namespace Database\Seeders;
namespace Database\Carbon;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class EntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('entreprises')->truncate();
        //Creation entreprise
        DB::table('entreprises')->insert([
            'id'=>'1',
            'Libelle'=>'NORA SHOP',
            'Email'=>'arsemeglo@gmail.com',
            'Telephone'=>'+22891207494',
            'Adresse'=>'',
            'DateCreation'=>Carbon::now(),
            'SaveNumber'=>'1',
            'Categ'=>'1',
        ]);
    }
}
