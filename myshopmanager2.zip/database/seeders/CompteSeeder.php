<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CompteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('comptes')->truncate();
         //Creation compte
       DB::table('comptes')->insert([
        'Solde'=>'2000000',
        'Libelle'=>'Caisse principale',
        'DateCreation'=>Carbon::now(),
        'EntrepriseId'=>'1',
        'SaveNumber'=>'1',
        // 'Anne/xeID'=>'1',
    ]);
    }
}
