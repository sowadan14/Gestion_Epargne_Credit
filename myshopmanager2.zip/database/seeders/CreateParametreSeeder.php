<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CreateParametreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
         DB::table('parametres')->truncate();
        
         //Creation emballage
         DB::table('parametres')->insert([
            'Taille'=>'14',
            'Police'=>'Cambria',
            'ColorEntete'=>'rgb(3, 39, 60)',
            'EmailNotification'=>'',
            'PasswordNotification'=>'0',
            'EntrepriseId'=>'1',
            'DateCreation'=>Carbon::now(),
            ]);
    }
}
