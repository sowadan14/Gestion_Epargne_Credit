<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CreateUniteProduitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         //
         DB::table('uniteproduits')->truncate();
        
         //Creation emballage
         DB::table('uniteproduits')->insert([
            'ProduitId'=>'1',
            'UniteId'=>'1',
            'Qte'=>'100',
            'PrixVente'=>'100',
            'PrixAchat'=>'100',
            ]);
        //
    }
}
