<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class TypeDepenseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('typedepenses')->truncate();
         //Creation compte
       DB::table('typedepenses')->insert([
        'Libelle'=>'Electricité',
        'DateCreation'=>Carbon::now(),
        'EntrepriseId'=>'1',
        'SaveNumber'=>'1',
        // 'Anne/xeID'=>'1',
    ]);
    }
}
