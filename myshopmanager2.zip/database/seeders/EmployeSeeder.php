<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class EmployeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('employes')->truncate();
          //Creation Employés
          DB::table('employes')->insert([
            'id'=>'1',
            'Nom'=>'SEMEGLO',
        'Prenoms'=>'Ablam',
        'Sexe'=>'M',
        'Email'=>'ablam.semeglo@gmail.com',
        'DateCreation'=>Carbon::now(),
        'DateNaissance'=>Carbon::now(),
        'Telephone'=>'+22891207494',
        'Adresse'=>'Ablogamé',
        'EntrepriseId'=>'1',
        'PosteId'=>'1',
        'SaveNumber'=>'1',
        // 'AnnexeID§/'=>'1',
        ]);

        // DB::table('employes')->insert([
        //     'id'=>'2',
        //     'FirstName'=>'SOWADAN',
        // 'LastName'=>'Justine',
        // 'Email'=>'just.sowadan@gmail.com',
        // 'Telephone'=>'+22891267494',
        // 'Adresse'=>'Ablogamé',
        // 'EntrepriseCateg'=>'1',
        // 'FonctionID'=>'2',
        // 'SaveNumber'=>'2',
        // 'AnnexeID'=>'1',
        // ]);
    }
}
