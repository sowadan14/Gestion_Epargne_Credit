<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmballageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('emballages')->truncate();
        
 //Creation emballage
 DB::table('emballages')->insert([
    'id'=>'1',
    'Libelle'=>'Carton',
    'EntrepriseId'=>'1',
    'DateCreation'=>Carbon::now(),
    ]);
    }
}
