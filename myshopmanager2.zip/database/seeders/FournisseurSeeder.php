<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FournisseurSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('fournisseurs')->truncate();
          //Creation client
          DB::table('fournisseurs')->insert([
            'Libelle'=>'Autre Frs',
        'Email'=>'ablam.semeglo@gmail.com',
        'Telephone'=>'+22891207494',
        'Adresse'=>'Ablogamé',
        'EntrepriseId'=>'1',
        'SaveNumber'=>'1',
        'DateCreation'=>Carbon::now(),
        // 'AnnexeID'=>'1',
        ]);
    }
}
