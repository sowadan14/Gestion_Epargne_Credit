<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CreateDetailscompteTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
