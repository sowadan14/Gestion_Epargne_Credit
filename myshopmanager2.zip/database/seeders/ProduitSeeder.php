<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProduitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('produits')->truncate();
           //Creation produit
           DB::table('produits')->insert([
            'id'=>'1',
            'Libelle'=>'Coca33',
                    'Prod_Logo'=>'',
                    'Qte'=>'10',
                    'DateCreation'=>Carbon::now(),
                    'EntrepriseId'=>'1',
                    'SaveNumber'=>'1',
                    'PU'=>'300',
            ]);
    }
}
