<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use App\Models\User;

// use Illuminate\Database\Eloquent\Model as Eloquent;

class DatabaseSeeder extends Seeder
{

    //  Eloquent::unguard();

    //disable foreign key check for this connection before running seeders
    //   DB::statement('SET FOREIGN_KEY_CHECKS=0;');
    /**
     * Seed the application's database.
     *
     * @return void
     */

    public function run()
    {
        Schema::disableForeignKeyConstraints();

        $this->call(SexeSeeder::class);
        $this->call(EntrepriseSeeder::class);
        $this->call(ClientSeeder::class);
        $this->call(CompteSeeder::class);
        $this->call(FournisseurSeeder::class);
        // $this->call(TypeDepenseSeeder::class);
        $this->call(PosteSeeder::class);
        $this->call(ProduitSeeder::class);
        $this->call(EmployeSeeder::class);
        $this->call(OtherDataSeeder::class);
        // $this->call(CreateParametreSeeder::class);
        $this->call(CreateUniteProduitSeeder::class);
        $this->call(PermissionTableSeeder::class);
        // $this->call(CreateParametreSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(CreateAdminUserSeeder::class);
        //  DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        Schema::enableForeignKeyConstraints();
    }
}

class CreateAdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        //Admin Seeder
        // $user = User::create([
        //     'name' => 'LaravelTuts', 
        //     'email' => 'admin@laraveltuts.com',
        //     'password' => bcrypt('password')
        // ]);

        $user = User::create([
            'EmployeId' => '1',
            'Email' => 'permission@gmail.com',
            'SuperAdmin' => '1',
            'password' => Hash::make('123456789'),
            // 'AnnexeID'=>'1',
            'EntrepriseId' => '1',
            //    'DateCreation'=>Carbon::now(),
            // 'SaveNumber'=>'1',
            'ImageUser' => '',
        ]);

        $role = Role::create(['Nom' => 'Admin', 'EntrepriseId' => '1']);

        $permissions = Permission::pluck('id', 'id')->all();

        $role->syncPermissions($permissions);

        $user->assignRole([$role->id]);
        Schema::enableForeignKeyConstraints();
    }
}

class OtherDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('couleurs')->insert(['text' => '#607D8B', 'value' => '#607D8B']);
        DB::table('couleurs')->insert(['text' => '#967ADC', 'value' => '#967ADC']);
        DB::table('couleurs')->insert(['text' => '#DA4453', 'value' => '#DA4453']);
        DB::table('couleurs')->insert(['text' => '#37BC9B', 'value' => '#37BC9B']);
        DB::table('couleurs')->insert(['text' => '#2196F3', 'value' => '#2196F3']);
        DB::table('couleurs')->insert(['text' => '#00BCD4', 'value' => '#00BCD4']);
        DB::table('couleurs')->insert(['text' => '#E91E63', 'value' => '#E91E63']);
        DB::table('couleurs')->insert(['text' => '#1D2B36', 'value' => '#1D2B36']);
        DB::table('couleurs')->insert(['text' => '#216ac4', 'value' => '#216ac4']);
        DB::table('couleurs')->insert(['text' => '#F57F17', 'value' => '#F57F17']);



        DB::table('fonts')->insert(['text' => 'CoolJazz', 'value' => 'CoolJazz']);
        DB::table('fonts')->insert(['text' => 'Trebuchet MS, sans-serif', 'value' => 'Trebuchet MS, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Arial, sans-serif', 'value' => 'Arial, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Helvetica, sans-serif', 'value' => 'Helvetica, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Verdana, sans-serif', 'value' => 'Verdana, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Gill Sans, sans-serif', 'value' => 'Gill Sans, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Times, Times New Roman, serif', 'value' => 'Times, Times New Roman, serif']);
        DB::table('fonts')->insert(['text' => 'Georgia, serif', 'value' => 'Georgia, serif']);
        DB::table('fonts')->insert(['text' => 'monospace', 'value' => 'monospace']);
        DB::table('fonts')->insert(['text' => 'Cambria', 'value' => 'Cambria']);
        DB::table('fonts')->insert(['text' => 'Comic Sans MS, Comic Sans, cursive', 'value' => 'Comic Sans MS, Comic Sans, cursive']);
        DB::table('fonts')->insert(['text' => 'Brush Script MT, Brush Script Std, cursive', 'value' => 'Brush Script MT, Brush Script Std, cursive']);
        DB::table('fonts')->insert(['text' => 'fantasy', 'value' => 'fantasy']);
        DB::table('fonts')->insert(['text' => 'Trattatello, fantasy', 'value' => 'Trattatello, fantasy']);
        DB::table('fonts')->insert(['text' => 'Lucida, sans-serif', 'value' => 'Lucida, sans-serif']);
        DB::table('fonts')->insert(['text' => 'Palatino, serif', 'value' => 'Palatino, serif']);
        DB::table('fonts')->insert(['text' => 'Bookman, serif', 'value' => 'Bookman, serif']);
        DB::table('fonts')->insert(['text' => 'New Century Schoolbook, serif', 'value' => 'New Century Schoolbook, serif']);
        DB::table('fonts')->insert(['text' => 'Lucidatypewriter, monospace', 'value' => 'Lucidatypewriter, monospace']);
        DB::table('fonts')->insert(['text' => 'Courier New, monospace', 'value' => 'Courier New, monospace']);
        DB::table('fonts')->insert(['text' => 'Impact, fantasy', 'value' => 'Impact, fantasy']);
        DB::table('fonts')->insert(['text' => 'cursive', 'value' => 'cursive']);
        DB::table('fonts')->insert(['text' => 'Garamond', 'value' => 'Garamond']);
        DB::table('fonts')->insert(['text' => 'Century Gothic', 'value' => 'Century Gothic']);
        DB::table('fonts')->insert(['text' => 'New Century Schoolbook', 'value' => 'New Century Schoolbook']);
        DB::table('fonts')->insert(['text' => 'Brush Script Std', 'value' => 'Brush Script Std']);
        DB::table('fonts')->insert(['text' => 'Copperplate', 'value' => 'Copperplate']);
        DB::table('fonts')->insert(['text' => 'papyrus', 'value' => 'papyrus']);
        DB::table('fonts')->insert(['text' => 'Bahnschrift SemiLight', 'value' => 'Bahnschrift SemiLight']);
        DB::table('fonts')->insert(['text' => 'Gabriola', 'value' => 'Gabriola']);
        DB::table('fonts')->insert(['text' => 'Lucida Handwriting', 'value' => 'Lucida Handwriting']);
        DB::table('fonts')->insert(['text' => 'Lucida Sans Typewriter', 'value' => 'Lucida Sans Typewriter']);
        DB::table('fonts')->insert(['text' => 'MS Gothic', 'value' => 'MS Gothic']);
    }
}


class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Permissions
        //   $permissions = [
        Permission::create(['name' => 'listrole', 'Parent' => 'Rôle', 'NumParent' => '1', 'TypeParent' => 'P1', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createrole', 'Parent' => 'Rôle', 'NumParent' => '1', 'TypeParent' => 'P1', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editrole', 'Parent' => 'Rôle', 'NumParent' => '1', 'TypeParent' => 'P1', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleterole', 'Parent' => 'Rôle', 'NumParent' => '1', 'TypeParent' => 'P1', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listposte', 'Parent' => 'Poste', 'NumParent' => '2', 'TypeParent' => 'P2', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createposte', 'Parent' => 'Poste', 'NumParent' => '2', 'TypeParent' => 'P2', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editposte', 'Parent' => 'Poste', 'NumParent' => '2', 'TypeParent' => 'P2', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteposte', 'Parent' => 'Poste', 'NumParent' => '2', 'TypeParent' => 'P2', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listuser', 'Parent' => 'Utilisateur', 'NumParent' => '3', 'TypeParent' => 'P3', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createuser', 'Parent' => 'Utilisateur', 'NumParent' => '3', 'TypeParent' => 'P3', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'edituser', 'Parent' => 'Utilisateur', 'NumParent' => '3', 'TypeParent' => 'P3', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteuser', 'Parent' => 'Utilisateur', 'NumParent' => '3', 'TypeParent' => 'P3', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listentreprise', 'Parent' => 'Entreprise', 'NumParent' => '4', 'TypeParent' => 'P4', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createentreprise', 'Parent' => 'Entreprise', 'NumParent' => '4', 'TypeParent' => 'P4', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editentreprise', 'Parent' => 'Entreprise', 'NumParent' => '4', 'TypeParent' => 'P4', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteentreprise', 'Parent' => 'Entreprise', 'NumParent' => '4', 'TypeParent' => 'P4', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listemploye', 'Parent' => 'Employé', 'NumParent' => '5', 'TypeParent' => 'P5', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createemploye', 'Parent' => 'Employé', 'NumParent' => '5', 'TypeParent' => 'P5', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editemploye', 'Parent' => 'Employé', 'NumParent' => '5', 'TypeParent' => 'P5', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteemploye', 'Parent' => 'Employé', 'NumParent' => '5', 'TypeParent' => 'P5', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listclient', 'Parent' => 'Client', 'NumParent' => '6', 'TypeParent' => 'P6', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createclient', 'Parent' => 'Client', 'NumParent' => '6', 'TypeParent' => 'P6', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editclient', 'Parent' => 'Client', 'NumParent' => '6', 'TypeParent' => 'P6', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteclient', 'Parent' => 'Client', 'NumParent' => '6', 'TypeParent' => 'P6', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listproduit', 'Parent' => 'Produit', 'NumParent' => '7', 'TypeParent' => 'P7', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createproduit', 'Parent' => 'Produit', 'NumParent' => '7', 'TypeParent' => 'P7', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editproduit', 'Parent' => 'Produit', 'NumParent' => '7', 'TypeParent' => 'P7', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteproduit', 'Parent' => 'Produit', 'NumParent' => '7', 'TypeParent' => 'P7', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listfournisseur', 'Parent' => 'Fournisseur', 'NumParent' => '8', 'TypeParent' => 'P8', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createfournisseur', 'Parent' => 'Fournisseur', 'NumParent' => '8', 'TypeParent' => 'P8', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editfournisseur', 'Parent' => 'Fournisseur', 'NumParent' => '8', 'TypeParent' => 'P8', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletefournisseur', 'Parent' => 'Fournisseur', 'NumParent' => '8', 'TypeParent' => 'P8', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listcompte', 'Parent' => 'Compte', 'NumParent' => '9', 'TypeParent' => 'P9', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createcompte', 'Parent' => 'Compte', 'NumParent' => '9', 'TypeParent' => 'P9', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editcompte', 'Parent' => 'Compte', 'NumParent' => '9', 'TypeParent' => 'P9', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletecompte', 'Parent' => 'Compte', 'NumParent' => '9', 'TypeParent' => 'P9', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listtypedepense', 'Parent' => 'Type dépense', 'NumParent' => '10', 'TypeParent' => 'P10', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createtypedepense', 'Parent' => 'Type dépense', 'NumParent' => '10', 'TypeParent' => 'P10', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'edittypedepense', 'Parent' => 'Type dépense', 'NumParent' => '10', 'TypeParent' => 'P10', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletetypedepense', 'Parent' => 'Type dépense', 'NumParent' => '10', 'TypeParent' => 'P10', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'listdepense', 'Parent' => 'Dépense', 'NumParent' => '11', 'TypeParent' => 'P11', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createdepense', 'Parent' => 'Dépense', 'NumParent' => '11', 'TypeParent' => 'P11', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editdepense', 'Parent' => 'Dépense', 'NumParent' => '11', 'TypeParent' => 'P11', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletedepense', 'Parent' => 'Dépense', 'NumParent' => '11', 'TypeParent' => 'P11', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
      
        Permission::create(['name' => 'listunite', 'Parent' => 'Unité', 'NumParent' => '14', 'TypeParent' => 'P14', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createunite', 'Parent' => 'Unité', 'NumParent' => '14', 'TypeParent' => 'P14', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editunite', 'Parent' => 'Unité', 'NumParent' => '14', 'TypeParent' => 'P14', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteunite', 'Parent' => 'Unité', 'NumParent' => '14', 'TypeParent' => 'P14', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);


        Permission::create(['name' => 'listmodepaiement', 'Parent' => 'Mode paiement', 'NumParent' => '15', 'TypeParent' => 'P15', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createmodepaiement', 'Parent' => 'Mode paiement', 'NumParent' => '15', 'TypeParent' => 'P15', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editmodepaiement', 'Parent' => 'Mode paiement', 'NumParent' => '15', 'TypeParent' => 'P15', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletemodepaiement', 'Parent' => 'Mode paiement', 'NumParent' => '15', 'TypeParent' => 'P15', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);

        Permission::create(['name' => 'listtypeproduit', 'Parent' => 'Type produit', 'NumParent' => '16', 'TypeParent' => 'P16', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createtypeproduit', 'Parent' => 'Type produit', 'NumParent' => '16', 'TypeParent' => 'P16', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'edittypeproduit', 'Parent' => 'Type produit', 'NumParent' => '16', 'TypeParent' => 'P16', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletetypeproduit', 'Parent' => 'Type produit', 'NumParent' => '16', 'TypeParent' => 'P16', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);


        Permission::create(['name' => 'listparam', 'Parent' => 'Paramètres', 'NumParent' => '17', 'TypeParent' => 'P17', 'Libelle' => 'Détails', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'editparam', 'Parent' => 'Paramètres', 'NumParent' => '17', 'TypeParent' => 'P17', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);



        Permission::create(['name' => 'listcategproduit', 'Parent' => 'Famille produit', 'NumParent' => '18', 'TypeParent' => 'P18', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createcategproduit', 'Parent' => 'Famille produit', 'NumParent' => '18', 'TypeParent' => 'P18', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editcategproduit', 'Parent' => 'Famille produit', 'NumParent' => '18', 'TypeParent' => 'P18', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletecategproduit', 'Parent' => 'Famille produit', 'NumParent' => '18', 'TypeParent' => 'P18', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);


        Permission::create(['name' => 'listalist', 'Parent' => 'Achat', 'NumParent' => '19', 'TypeParent' => 'P19', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createalist', 'Parent' => 'Achat', 'NumParent' => '19', 'TypeParent' => 'P19', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editalist', 'Parent' => 'Achat', 'NumParent' => '19', 'TypeParent' => 'P19', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletealist', 'Parent' => 'Achat', 'NumParent' => '19', 'TypeParent' => 'P19', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);


        

        Permission::create(['name' => 'listarecep', 'Parent' => 'Réception commande', 'NumParent' => '21', 'TypeParent' => 'P21', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createarecep', 'Parent' => 'Réception commande', 'NumParent' => '21', 'TypeParent' => 'P21', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editarecep', 'Parent' => 'Réception commande', 'NumParent' => '21', 'TypeParent' => 'P21', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletearecep', 'Parent' => 'Réception commande', 'NumParent' => '21', 'TypeParent' => 'P21', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-121"></i></span></a>']);


        Permission::create(['name' => 'listafact', 'Parent' => 'Facture fournisseur', 'NumParent' => '22', 'TypeParent' => 'P22', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createafact', 'Parent' => 'Facture fournisseur', 'NumParent' => '22', 'TypeParent' => 'P22', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editafact', 'Parent' => 'Facture fournisseur', 'NumParent' => '22', 'TypeParent' => 'P22', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteafact', 'Parent' => 'Facture fournisseur', 'NumParent' => '22', 'TypeParent' => 'P22', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-122"></i></span></a>']);


        Permission::create(['name' => 'listapaiement', 'Parent' => 'Paiement fournisseur', 'NumParent' => '23', 'TypeParent' => 'P23', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createapaiement', 'Parent' => 'Paiement fournisseur', 'NumParent' => '23', 'TypeParent' => 'P23', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editapaiement', 'Parent' => 'Paiement fournisseur', 'NumParent' => '23', 'TypeParent' => 'P23', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteapaiement', 'Parent' => 'Paiement fournisseur', 'NumParent' => '23', 'TypeParent' => 'P23', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-123"></i></span></a>']);



        Permission::create(['name' => 'listvlist', 'Parent' => 'Vente', 'NumParent' => '24', 'TypeParent' => 'P24', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createvlist', 'Parent' => 'Vente', 'NumParent' => '24', 'TypeParent' => 'P24', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editvlist', 'Parent' => 'Vente', 'NumParent' => '24', 'TypeParent' => 'P24', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletevlist', 'Parent' => 'Vente', 'NumParent' => '24', 'TypeParent' => 'P24', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-125"></i></span></a>']);

      
        Permission::create(['name' => 'listvlivr', 'Parent' => 'Livraison commande', 'NumParent' => '26', 'TypeParent' => 'P26', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createvlivr', 'Parent' => 'Livraison commande', 'NumParent' => '26', 'TypeParent' => 'P26', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editvlivr', 'Parent' => 'Livraison commande', 'NumParent' => '26', 'TypeParent' => 'P26', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletevlivr', 'Parent' => 'Livraison commande', 'NumParent' => '26', 'TypeParent' => 'P26', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-126"></i></span></a>']);


        Permission::create(['name' => 'listvfact', 'Parent' => 'Facture client', 'NumParent' => '27', 'TypeParent' => 'P27', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createvfact', 'Parent' => 'Facture client', 'NumParent' => '27', 'TypeParent' => 'P27', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editvfact', 'Parent' => 'Facture client', 'NumParent' => '27', 'TypeParent' => 'P27', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletevfact', 'Parent' => 'Facture client', 'NumParent' => '27', 'TypeParent' => 'P27', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-127"></i></span></a>']);


        Permission::create(['name' => 'listvpaiement', 'Parent' => 'Paiement client', 'NumParent' => '28', 'TypeParent' => 'P28', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createvpaiement', 'Parent' => 'Paiement client', 'NumParent' => '28', 'TypeParent' => 'P28', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editvpaiement', 'Parent' => 'Paiement client', 'NumParent' => '28', 'TypeParent' => 'P28', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletevpaiement', 'Parent' => 'Paiement client', 'NumParent' => '28', 'TypeParent' => 'P28', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-128"></i></span></a>']);

        Permission::create(['name' => 'listacmde', 'Parent' => 'Commande fournisseur', 'NumParent' => '20', 'TypeParent' => 'P20', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createacmde', 'Parent' => 'Commande fournisseur', 'NumParent' => '20', 'TypeParent' => 'P20', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editacmde', 'Parent' => 'Commande fournisseur', 'NumParent' => '20', 'TypeParent' => 'P20', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deleteacmde', 'Parent' => 'Commande fournisseur', 'NumParent' => '20', 'TypeParent' => 'P20', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-120"></i></span></a>']);
        Permission::create(['name' => 'clotureacmde', 'Parent' => 'Commande fournisseur', 'NumParent' => '20', 'TypeParent' => 'P20', 'Libelle' => 'Clôturer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Cloturer" class="btn btn-primary btn-sm"  title="Clôturer"><span class="white"><i class="ace-icon fa fa-check-circle-o bigger-120"></i></span></a>']);
      
        Permission::create(['name' => 'listvcmde', 'Parent' => 'Commande client', 'NumParent' => '25', 'TypeParent' => 'P25', 'Libelle' => 'Liste', 'Lien' => '<a  data-toggle="tooltip"  data-original-title="Details" class="btn btn-default btn-sm" title="Details"><span class="blue"><i class="ace-icon fa fa-eye"></i></span></a>']);
        Permission::create(['name' => 'createvcmde', 'Parent' => 'Commande client', 'NumParent' => '25', 'TypeParent' => 'P25', 'Libelle' => 'Créer', 'Lien' => '<a class="btn btn-sm btn-round btn-primary"  ><span class=" glyphicon glyphicon-plus"></span></a>']);
        Permission::create(['name' => 'editvcmde', 'Parent' => 'Commande client', 'NumParent' => '25', 'TypeParent' => 'P25', 'Libelle' => 'Modifier', 'Lien' => '<a   data-original-title="Modifier" class="btn btn-warning btn-sm"  title="Modifier"><span class="white"><i class="glyphicon glyphicon-edit"></i></span></a>']);
        Permission::create(['name' => 'deletevcmde', 'Parent' => 'Commande client', 'NumParent' => '25', 'TypeParent' => 'P25', 'Libelle' => 'Supprimer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Supprimer" class="btn btn-danger btn-sm"  title="Supprimer"><span class="white"><i class="ace-icon fa fa-trash-o bigger-125"></i></span></a>']);
        Permission::create(['name' => 'cloturevcmde', 'Parent' => 'Commande client', 'NumParent' => '25', 'TypeParent' => 'P25', 'Libelle' => 'Clôturer', 'Lien' => '<a  data-toggle="tooltip"   data-original-title="Cloturer" class="btn btn-primary btn-sm"  title="Clôturer"><span class="white"><i class="ace-icon fa fa-check-circle-o bigger-125"></i></span></a>']);
       


    }
}

class SexeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('sexes')->insert([
            'text' => 'Masculin',
            'value' => 'M',
        ]);

        DB::table('sexes')->insert([
            'text' => 'Féminin',
            'value' => 'F',
        ]);
    }
}


class CreateUniteProduitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('uniteproduits')->truncate();

        //Creation emballage
        DB::table('uniteproduits')->insert([
            'ProduitId' => '1',
            'UniteId' => '1',
            'PrixVente' => '300',
            'PrixAchat' => '250',
            'Qte' => '0',
            'Coef' => '0.25',
        ]);
        //
    }
}

class CreateParametreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('parametres')->truncate();


        DB::table('parametres')->insert([
            'Taille' => '14',
            'Police' => 'Cambria',
            'ColorEntete' => 'rgb(3, 39, 60)',
            'LogoEntreprise' => '',
            'EmailNotification' => '',
            'PasswordNotification' => '',
            'EntrepriseId' => '1',
            // 'DateCreation'=>Carbon::now(),
            'Nom' => 'NORA SHOP',
            'NomReduit' => 'NORA SHOP',
            'Email' => 'arsemeglo@gmail.com',
            'Telephone' => '+22891207494',
            'Adresse' => '',
        ]);
    }
}

class EmballageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('emballages')->truncate();

        //Creation emballage
        DB::table('emballages')->insert([
            'id' => '1',
            'Libelle' => 'Carton',
            'EntrepriseId' => '1',
            // 'DateCreation'=>Carbon::now(),
        ]);
    }
}


class EntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('entreprises')->truncate();
        //Creation entreprise
        DB::table('entreprises')->insert([
            'id' => '1',
            'Taille' => '14',
            'Police' => 'Cambria',
            'ColorEntete' => 'rgb(3, 39, 60)',
            'ColorSidebar' => '',
            'LogoEntreprise' => '',
            'EmailNotification' => '',
            'PasswordNotification' => '',
            'Nom' => 'NORA SHOP',
            'NomReduit' => 'NORA SHOP',
            'Email' => 'arsemeglo@gmail.com',
            'Telephone' => '+22891207494',
            'Adresse' => '',
        ]);
    }
}


class CompteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('comptes')->truncate();
        //Creation compte
        DB::table('comptes')->insert([
            'Solde' => '0', //Problem ici
            'SoldeInitial' => '2000', //Problem ici
            'Libelle' => 'Caisse principale',
            // 'DateCreation'=>Carbon::now(),
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
            // 'Anne/xeID'=>'1',
        ]);
    }
}


class FournisseurSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('fournisseurs')->truncate();
        //Creation client
        DB::table('fournisseurs')->insert([
            'Nom' => 'Autre Frs',
            'Email' => '',
            'Telephone' => '',
            'Adresse' => '',
            'EntrepriseId' => '1',
        ]);


        DB::table('avoirfrs')->truncate();
        DB::table('avoirfrs')->insert([
            'FournisseurId' => '1',
            'Montant' => '0',
            'EntrepriseId' => '1',
        ]);
    }
}

class TypeDepenseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('typedepenses')->truncate();
        //Creation compte
        DB::table('typedepenses')->insert([
            'Libelle' => 'Electricité',
            'DateCreation' => Carbon::now(),
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
            // 'Anne/xeID'=>'1',
        ]);
    }
}


class PosteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('postes')->truncate();
        //Creation des users
        DB::table('postes')->insert([
            'Libelle' => 'Ditecteur général',
            // 'DateCreation'=>Carbon::now(),
            'EntrepriseId' => '1',
        ]);
    }
}


class ProduitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        DB::table('unites')->truncate();
        //Creation unité
        DB::table('unites')->insert([
            'id' => '1',
            'Nom' => '####',
            'Code' => 'U1',
            'Status' => 1,
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
        ]);


        DB::table('typeproduits')->truncate();
        //Creation unité
        DB::table('typeproduits')->insert([
            'id' => '1',
            'Nom' => 'Servie',
            'Code' => 'T1',
            'Status' => '1',
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
        ]);

        DB::table('typeproduits')->truncate();
        //Creation unité
        DB::table('typeproduits')->insert([
            'id' => '2',
            'Nom' => 'Stockable',
            'Code' => 'T2',
            'Status' => '1',
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
        ]);


        DB::table('categproduits')->truncate();
        //Creation unité
        DB::table('categproduits')->insert([
            'id' => '1',
            'Nom' => 'Générale',
            'Code' => 'C1',
            'Status' => '1',
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
        ]);

        DB::table('produits')->truncate();
        //Creation produit
        DB::table('produits')->insert([
            'id' => '1',
            'UniteId' => '1',
            'TypeProduitId' => '1',
            'CategProduitId' => '1',
            'Libelle' => 'Autre produit',
            'Prod_Logo' => '',
            'Qte' => '0',
            // 'DateCreation'=>Carbon::now(),
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
            'PU' => '300',
        ]);
        //

    }
}



class ClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('clients')->truncate();
        //Creation client
        DB::table('clients')->insert([
            'Nom' => 'AMA Ablam',
            // 'Prenoms'=>'',
            // 'Sexe'=>'M',
            'Email' => '',
            'Telephone' => '',
            'Adresse' => '',
            'EntrepriseId' => '1',
            // 'SaveNumber'=>'1',
            // 'DateCreation'=>Carbon::now(),
            // 'DateNaissance'=>Carbon::now(),
            // 'AnnexeID'=>'1',
        ]);


        DB::table('avoirclts')->truncate();
        DB::table('avoirclts')->insert([
            'ClientId' => '1',
            'Montant' => '0',
            'EntrepriseId' => '1',
        ]);
    }
}


class EmployeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('employes')->truncate();
        //Creation Employés
        DB::table('employes')->insert([
            'id' => '1',
            'Nom' => 'SEMEGLO Ablam',
            // 'Prenoms'=>'Ablam',
            'Sexe' => 'M',
            'Email' => 'ablam.semeglo@gmail.com',
            // 'DateCreation'=>Carbon::now(),
            'DateNaissance' => Carbon::now(),
            'Telephone' => '+22891207494',
            'Adresse' => 'Ablogamé',
            'EntrepriseId' => '1',
            'PosteId' => '1',
            // 'SaveNumber'=>'1',
            // 'AnnexeID§/'=>'1',
        ]);
    }
}

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->truncate();
        //Creation des users
        DB::table('users')->insert([
            'EmployeId' => '1',
            'Email' => 'arsemeglo@gmail.com',
            'SuperAdmin' => '1',
            'password' => Hash::make('123456789'),
            // 'AnnexeID'=>'1',
            'EntrepriseId' => '1',
            // 'DateCreation'=>Carbon::now(),
            // 'SaveNumber'=>'1',
            'ImageUser' => '',
        ]);


        //Creation des users
        DB::table('users')->insert([
            'EmployeId' => '1',
            'Email' => 'macherie@gmail.com',
            'SuperAdmin' => '1',
            'password' => Hash::make('123456789'),
            // 'AnnexeID'=>'1',
            'EntrepriseId' => '1',
            // 'DateCreation'=>Carbon::now(),
            // 'SaveNumber'=>'1',
            'ImageUser' => '',
        ]);
    }
}
